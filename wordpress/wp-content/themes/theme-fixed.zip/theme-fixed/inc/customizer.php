<?php
/**
 * Funções de personalização do tema para o Customizer
 *
 * @package Theme_Espingardaria
 */

if (!defined('ABSPATH')) {
    exit;
}

function theme_espingardaria_customize_register($wp_customize) {
    // Seção Geral da Página Inicial
    $wp_customize->add_section('theme_espingardaria_home', array(
        'title'    => __('Configurações da Página Inicial', 'theme-espingardaria'),
        'priority' => 20,
    ));

    // Banner Principal (Slider)
    $wp_customize->add_setting('theme_espingardaria_show_banner', array(
        'default'           => true,
        'sanitize_callback' => 'theme_espingardaria_sanitize_checkbox',
    ));
    $wp_customize->add_control('theme_espingardaria_show_banner', array(
        'label'    => __('Mostrar Banner Principal', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'checkbox',
    ));

    // Categorias de Produtos
    $wp_customize->add_setting('theme_espingardaria_show_categories', array(
        'default'           => true,
        'sanitize_callback' => 'theme_espingardaria_sanitize_checkbox',
    ));
    $wp_customize->add_control('theme_espingardaria_show_categories', array(
        'label'    => __('Mostrar Categorias de Produtos', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('theme_espingardaria_categories_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('theme_espingardaria_categories_title', array(
        'label'    => __('Título da Seção de Categorias', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'text',
    ));

    // Produtos em Destaque
    $wp_customize->add_setting('theme_espingardaria_show_featured_products', array(
        'default'           => true,
        'sanitize_callback' => 'theme_espingardaria_sanitize_checkbox',
    ));
    $wp_customize->add_control('theme_espingardaria_show_featured_products', array(
        'label'    => __('Mostrar Produtos em Destaque', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('theme_espingardaria_featured_products_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('theme_espingardaria_featured_products_title', array(
        'label'    => __('Título da Seção de Produtos em Destaque', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('theme_espingardaria_featured_products_count', array(
        'default'           => 4,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('theme_espingardaria_featured_products_count', array(
        'label'    => __('Quantidade de Produtos em Destaque', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'number',
        'input_attrs' => array('min' => 1, 'max' => 12),
    ));

    // Seção de Treinamento
    $wp_customize->add_setting('theme_espingardaria_show_training', array(
        'default'           => true,
        'sanitize_callback' => 'theme_espingardaria_sanitize_checkbox',
    ));
    $wp_customize->add_control('theme_espingardaria_show_training', array(
        'label'    => __('Mostrar Seção de Treinamento', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('theme_espingardaria_training_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('theme_espingardaria_training_title', array(
        'label'    => __('Título da Seção de Treinamento', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('theme_espingardaria_training_text', array(
        'default'           => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('theme_espingardaria_training_text', array(
        'label'    => __('Texto da Seção de Treinamento', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'textarea',
    ));
    $wp_customize->add_setting('theme_espingardaria_training_button_text', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('theme_espingardaria_training_button_text', array(
        'label'    => __('Texto do Botão de Treinamento', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('theme_espingardaria_training_button_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('theme_espingardaria_training_button_url', array(
        'label'    => __('URL do Botão de Treinamento', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'url',
    ));
    $wp_customize->add_setting('theme_espingardaria_training_image', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'theme_espingardaria_training_image', array(
        'label'    => __('Imagem de Fundo do Treinamento', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'settings' => 'theme_espingardaria_training_image',
    )));

    // Seção de Munições
    $wp_customize->add_setting('theme_espingardaria_show_ammo', array(
        'default'           => true,
        'sanitize_callback' => 'theme_espingardaria_sanitize_checkbox',
    ));
    $wp_customize->add_control('theme_espingardaria_show_ammo', array(
        'label'    => __('Mostrar Seção de Munições', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('theme_espingardaria_ammo_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('theme_espingardaria_ammo_title', array(
        'label'    => __('Título da Seção de Munições', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('theme_espingardaria_ammo_text', array(
        'default'           => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('theme_espingardaria_ammo_text', array(
        'label'    => __('Texto da Seção de Munições', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'textarea',
    ));
    $wp_customize->add_setting('theme_espingardaria_ammo_button_text', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('theme_espingardaria_ammo_button_text', array(
        'label'    => __('Texto do Botão de Munições', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('theme_espingardaria_ammo_button_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('theme_espingardaria_ammo_button_url', array(
        'label'    => __('URL do Botão de Munições', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'url',
    ));
    $wp_customize->add_setting('theme_espingardaria_ammo_image', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'theme_espingardaria_ammo_image', array(
        'label'    => __('Imagem de Fundo de Munições', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'settings' => 'theme_espingardaria_ammo_image',
    )));

    // Compre em Qualquer Lugar
    $wp_customize->add_setting('theme_espingardaria_show_shop_anywhere', array(
        'default'           => true,
        'sanitize_callback' => 'theme_espingardaria_sanitize_checkbox',
    ));
    $wp_customize->add_control('theme_espingardaria_show_shop_anywhere', array(
        'label'    => __('Mostrar Seção Compre em Qualquer Lugar', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('theme_espingardaria_shop_anywhere_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('theme_espingardaria_shop_anywhere_title', array(
        'label'    => __('Título da Seção Compre em Qualquer Lugar', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'text',
    ));

    // Avaliações de Clientes
    $wp_customize->add_setting('theme_espingardaria_show_reviews', array(
        'default'           => true,
        'sanitize_callback' => 'theme_espingardaria_sanitize_checkbox',
    ));
    $wp_customize->add_control('theme_espingardaria_show_reviews', array(
        'label'    => __('Mostrar Seção de Avaliações', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('theme_espingardaria_reviews_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('theme_espingardaria_reviews_title', array(
        'label'    => __('Título da Seção de Avaliações', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'text',
    ));

    // Novos Produtos
    $wp_customize->add_setting('theme_espingardaria_show_new_products', array(
        'default'           => true,
        'sanitize_callback' => 'theme_espingardaria_sanitize_checkbox',
    ));
    $wp_customize->add_control('theme_espingardaria_show_new_products', array(
        'label'    => __('Mostrar Seção de Novos Produtos', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('theme_espingardaria_new_products_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('theme_espingardaria_new_products_title', array(
        'label'    => __('Título da Seção de Novos Produtos', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('theme_espingardaria_new_products_count', array(
        'default'           => 4,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('theme_espingardaria_new_products_count', array(
        'label'    => __('Quantidade de Novos Produtos', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'number',
        'input_attrs' => array('min' => 1, 'max' => 12),
    ));

    // Blog e Notícias
    $wp_customize->add_setting('theme_espingardaria_show_blog', array(
        'default'           => true,
        'sanitize_callback' => 'theme_espingardaria_sanitize_checkbox',
    ));
    $wp_customize->add_control('theme_espingardaria_show_blog', array(
        'label'    => __('Mostrar Seção de Blog', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('theme_espingardaria_blog_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('theme_espingardaria_blog_title', array(
        'label'    => __('Título da Seção de Blog', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('theme_espingardaria_blog_count', array(
        'default'           => 3,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('theme_espingardaria_blog_count', array(
        'label'    => __('Quantidade de Posts do Blog', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'number',
        'input_attrs' => array('min' => 1, 'max' => 12),
    ));

    // Sobre Nós
    $wp_customize->add_setting('theme_espingardaria_show_about', array(
        'default'           => true,
        'sanitize_callback' => 'theme_espingardaria_sanitize_checkbox',
    ));
    $wp_customize->add_control('theme_espingardaria_show_about', array(
        'label'    => __('Mostrar Seção Sobre Nós', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('theme_espingardaria_about_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('theme_espingardaria_about_title', array(
        'label'    => __('Título da Seção Sobre Nós', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'text',
    ));
    $wp_customize->add_setting('theme_espingardaria_about_text', array(
        'default'           => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('theme_espingardaria_about_text', array(
        'label'    => __('Texto da Seção Sobre Nós', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'type'     => 'textarea',
    ));
    $wp_customize->add_setting('theme_espingardaria_about_image', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'theme_espingardaria_about_image', array(
        'label'    => __('Imagem da Seção Sobre Nós', 'theme-espingardaria'),
        'section'  => 'theme_espingardaria_home',
        'settings' => 'theme_espingardaria_about_image',
    )));

    // Configurações do Header (mantidas do original)
    $wp_customize->add_section('theme_espingardaria_header', array(
        'title'    => __('Configurações do Header', 'theme-espingardaria'),
        'priority' => 30,
    ));

    // ... (manter as configurações existentes do header, redes sociais, cores, etc.)
}
add_action('customize_register', 'theme_espingardaria_customize_register');

function theme_espingardaria_sanitize_checkbox($checked) {
    return isset($checked) && true == $checked;
}

function theme_espingardaria_customizer_css() {
    ?>
    <style type="text/css">
        :root {
            --primary-color: <?php echo esc_attr(get_theme_mod('theme_espingardaria_primary_color', '#d9534f')); ?>;
            --secondary-color: <?php echo esc_attr(get_theme_mod('theme_espingardaria_secondary_color', '#333333')); ?>;
            --header-bg-color: <?php echo esc_attr(get_theme_mod('theme_espingardaria_header_bg_color', '#222222')); ?>;
            --topbar-bg-color: <?php echo esc_attr(get_theme_mod('theme_espingardaria_topbar_bg_color', '#111111')); ?>;
        }
        .top-bar { background-color: var(--topbar-bg-color); }
        .site-navigation { background-color: var(--header-bg-color); }
        .btn-primary, .btn-primary:hover, .btn-primary:focus {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        a { color: var(--primary-color); }
        a:hover { color: var(--secondary-color); }
    </style>
    <?php
}
add_action('wp_head', 'theme_espingardaria_customizer_css');