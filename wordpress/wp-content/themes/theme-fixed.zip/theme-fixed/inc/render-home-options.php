<?php
$options = get_option('theme_espingardaria_options', array());
?>
<div class="theme-options-section">
    <h2><?php esc_html_e('Configurações da Página Inicial', 'theme-espingardaria'); ?></h2>
    <label>
        <input type="checkbox" name="theme_espingardaria_options[show_banner]" <?php checked($options['show_banner'] ?? true); ?>>
        <?php esc_html_e('Mostrar Banner Principal', 'theme-espingardaria'); ?>
    </label>
</div>