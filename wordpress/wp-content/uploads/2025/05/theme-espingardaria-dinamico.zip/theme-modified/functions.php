<?php
/**
 * Funções e definições do tema
 *
 * @package Theme_Espingardaria
 */

if (!defined('ABSPATH')) {
    exit; // Saída direta se acessado diretamente
}

/**
 * Define constantes do tema
 */
define('THEME_ESPINGARDARIA_VERSION', '3.0.0');
define('THEME_ESPINGARDARIA_DIR', get_template_directory());
define('THEME_ESPINGARDARIA_URI', get_template_directory_uri());

/**
 * Configuração do tema
 */
function theme_espingardaria_setup() {
    // Adiciona suporte a tradução
    load_theme_textdomain('theme-espingardaria', THEME_ESPINGARDARIA_DIR . '/languages');

    // Adiciona suporte a recursos do WordPress
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));
    add_theme_support('customize-selective-refresh-widgets');

    // Registra menus
    register_nav_menus(array(
        'primary' => esc_html__('Menu Principal', 'theme-espingardaria'),
        'footer' => esc_html__('Menu Rodapé', 'theme-espingardaria'),
    ));

    // Tamanhos de imagem personalizados
    add_image_size('theme-espingardaria-featured', 1200, 600, true);
    add_image_size('theme-espingardaria-product', 600, 600, true);
    add_image_size('theme-espingardaria-thumbnail', 300, 300, true);
}
add_action('after_setup_theme', 'theme_espingardaria_setup');

/**
 * Registra áreas de widgets
 */
function theme_espingardaria_widgets_init() {
    register_sidebar(array(
        'name'          => esc_html__('Sidebar', 'theme-espingardaria'),
        'id'            => 'sidebar-1',
        'description'   => esc_html__('Adicione widgets aqui.', 'theme-espingardaria'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Rodapé 1', 'theme-espingardaria'),
        'id'            => 'footer-1',
        'description'   => esc_html__('Adicione widgets aqui.', 'theme-espingardaria'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Rodapé 2', 'theme-espingardaria'),
        'id'            => 'footer-2',
        'description'   => esc_html__('Adicione widgets aqui.', 'theme-espingardaria'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Rodapé 3', 'theme-espingardaria'),
        'id'            => 'footer-3',
        'description'   => esc_html__('Adicione widgets aqui.', 'theme-espingardaria'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Rodapé 4', 'theme-espingardaria'),
        'id'            => 'footer-4',
        'description'   => esc_html__('Adicione widgets aqui.', 'theme-espingardaria'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'theme_espingardaria_widgets_init');

/**
 * Enfileira scripts e estilos
 */
function theme_espingardaria_scripts() {
    // Bootstrap CSS
    wp_enqueue_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css', array(), '5.3.0');
    
    // Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css', array(), '6.0.0');
    
    // Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap', array(), null);
    
    // Tema CSS
    wp_enqueue_style('theme-espingardaria-style', get_stylesheet_uri(), array(), THEME_ESPINGARDARIA_VERSION);
    wp_enqueue_style('theme-espingardaria-main', THEME_ESPINGARDARIA_URI . '/css/style.css', array(), THEME_ESPINGARDARIA_VERSION);
    
    // Bootstrap JS
    wp_enqueue_script('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js', array('jquery'), '5.3.0', true);
    
    // Tema JS
    wp_enqueue_script('theme-espingardaria-main', THEME_ESPINGARDARIA_URI . '/js/main.js', array('jquery'), THEME_ESPINGARDARIA_VERSION, true);

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'theme_espingardaria_scripts');

/**
 * Registra o tipo de post personalizado para produtos
 */
function theme_espingardaria_register_post_types() {
    $labels = array(
        'name'                  => _x('Produtos', 'Post type general name', 'theme-espingardaria'),
        'singular_name'         => _x('Produto', 'Post type singular name', 'theme-espingardaria'),
        'menu_name'             => _x('Produtos', 'Admin Menu text', 'theme-espingardaria'),
        'name_admin_bar'        => _x('Produto', 'Add New on Toolbar', 'theme-espingardaria'),
        'add_new'               => __('Adicionar Novo', 'theme-espingardaria'),
        'add_new_item'          => __('Adicionar Novo Produto', 'theme-espingardaria'),
        'new_item'              => __('Novo Produto', 'theme-espingardaria'),
        'edit_item'             => __('Editar Produto', 'theme-espingardaria'),
        'view_item'             => __('Ver Produto', 'theme-espingardaria'),
        'all_items'             => __('Todos os Produtos', 'theme-espingardaria'),
        'search_items'          => __('Buscar Produtos', 'theme-espingardaria'),
        'parent_item_colon'     => __('Produtos Pai:', 'theme-espingardaria'),
        'not_found'             => __('Nenhum produto encontrado.', 'theme-espingardaria'),
        'not_found_in_trash'    => __('Nenhum produto encontrado na lixeira.', 'theme-espingardaria'),
        'featured_image'        => __('Imagem Destacada do Produto', 'theme-espingardaria'),
        'set_featured_image'    => __('Definir imagem destacada', 'theme-espingardaria'),
        'remove_featured_image' => __('Remover imagem destacada', 'theme-espingardaria'),
        'use_featured_image'    => __('Usar como imagem destacada', 'theme-espingardaria'),
        'archives'              => __('Arquivos de Produto', 'theme-espingardaria'),
        'insert_into_item'      => __('Inserir no produto', 'theme-espingardaria'),
        'uploaded_to_this_item' => __('Enviado para este produto', 'theme-espingardaria'),
        'filter_items_list'     => __('Filtrar lista de produtos', 'theme-espingardaria'),
        'items_list_navigation' => __('Navegação da lista de produtos', 'theme-espingardaria'),
        'items_list'            => __('Lista de produtos', 'theme-espingardaria'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'produto'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-cart',
        'supports'           => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
    );

    register_post_type('produto', $args);

    // Registra taxonomias para produtos
    $category_labels = array(
        'name'                       => _x('Categorias de Produto', 'taxonomy general name', 'theme-espingardaria'),
        'singular_name'              => _x('Categoria de Produto', 'taxonomy singular name', 'theme-espingardaria'),
        'search_items'               => __('Buscar Categorias', 'theme-espingardaria'),
        'popular_items'              => __('Categorias Populares', 'theme-espingardaria'),
        'all_items'                  => __('Todas as Categorias', 'theme-espingardaria'),
        'parent_item'                => __('Categoria Pai', 'theme-espingardaria'),
        'parent_item_colon'          => __('Categoria Pai:', 'theme-espingardaria'),
        'edit_item'                  => __('Editar Categoria', 'theme-espingardaria'),
        'update_item'                => __('Atualizar Categoria', 'theme-espingardaria'),
        'add_new_item'               => __('Adicionar Nova Categoria', 'theme-espingardaria'),
        'new_item_name'              => __('Novo Nome de Categoria', 'theme-espingardaria'),
        'separate_items_with_commas' => __('Separar categorias com vírgulas', 'theme-espingardaria'),
        'add_or_remove_items'        => __('Adicionar ou remover categorias', 'theme-espingardaria'),
        'choose_from_most_used'      => __('Escolher entre as categorias mais usadas', 'theme-espingardaria'),
        'not_found'                  => __('Nenhuma categoria encontrada.', 'theme-espingardaria'),
        'menu_name'                  => __('Categorias', 'theme-espingardaria'),
    );

    $category_args = array(
        'hierarchical'          => true,
        'labels'                => $category_labels,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'query_var'             => true,
        'rewrite'               => array('slug' => 'categoria-produto'),
    );

    register_taxonomy('categoria-produto', array('produto'), $category_args);

    // Taxonomia para marcas
    $brand_labels = array(
        'name'                       => _x('Marcas', 'taxonomy general name', 'theme-espingardaria'),
        'singular_name'              => _x('Marca', 'taxonomy singular name', 'theme-espingardaria'),
        'search_items'               => __('Buscar Marcas', 'theme-espingardaria'),
        'popular_items'              => __('Marcas Populares', 'theme-espingardaria'),
        'all_items'                  => __('Todas as Marcas', 'theme-espingardaria'),
        'edit_item'                  => __('Editar Marca', 'theme-espingardaria'),
        'update_item'                => __('Atualizar Marca', 'theme-espingardaria'),
        'add_new_item'               => __('Adicionar Nova Marca', 'theme-espingardaria'),
        'new_item_name'              => __('Novo Nome de Marca', 'theme-espingardaria'),
        'separate_items_with_commas' => __('Separar marcas com vírgulas', 'theme-espingardaria'),
        'add_or_remove_items'        => __('Adicionar ou remover marcas', 'theme-espingardaria'),
        'choose_from_most_used'      => __('Escolher entre as marcas mais usadas', 'theme-espingardaria'),
        'not_found'                  => __('Nenhuma marca encontrada.', 'theme-espingardaria'),
        'menu_name'                  => __('Marcas', 'theme-espingardaria'),
    );

    $brand_args = array(
        'hierarchical'          => false,
        'labels'                => $brand_labels,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'query_var'             => true,
        'rewrite'               => array('slug' => 'marca'),
    );

    register_taxonomy('marca', array('produto'), $brand_args);

    // Taxonomia para calibres
    $caliber_labels = array(
        'name'                       => _x('Calibres', 'taxonomy general name', 'theme-espingardaria'),
        'singular_name'              => _x('Calibre', 'taxonomy singular name', 'theme-espingardaria'),
        'search_items'               => __('Buscar Calibres', 'theme-espingardaria'),
        'popular_items'              => __('Calibres Populares', 'theme-espingardaria'),
        'all_items'                  => __('Todos os Calibres', 'theme-espingardaria'),
        'edit_item'                  => __('Editar Calibre', 'theme-espingardaria'),
        'update_item'                => __('Atualizar Calibre', 'theme-espingardaria'),
        'add_new_item'               => __('Adicionar Novo Calibre', 'theme-espingardaria'),
        'new_item_name'              => __('Novo Nome de Calibre', 'theme-espingardaria'),
        'separate_items_with_commas' => __('Separar calibres com vírgulas', 'theme-espingardaria'),
        'add_or_remove_items'        => __('Adicionar ou remover calibres', 'theme-espingardaria'),
        'choose_from_most_used'      => __('Escolher entre os calibres mais usados', 'theme-espingardaria'),
        'not_found'                  => __('Nenhum calibre encontrado.', 'theme-espingardaria'),
        'menu_name'                  => __('Calibres', 'theme-espingardaria'),
    );

    $caliber_args = array(
        'hierarchical'          => false,
        'labels'                => $caliber_labels,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'query_var'             => true,
        'rewrite'               => array('slug' => 'calibre'),
    );

    register_taxonomy('calibre', array('produto'), $caliber_args);
}
add_action('init', 'theme_espingardaria_register_post_types');

/**
 * Adiciona campos personalizados para produtos
 */
function theme_espingardaria_add_product_meta_boxes() {
    add_meta_box(
        'theme_espingardaria_product_details',
        __('Detalhes do Produto', 'theme-espingardaria'),
        'theme_espingardaria_product_details_callback',
        'produto',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'theme_espingardaria_add_product_meta_boxes');

/**
 * Renderiza o conteúdo da meta box de detalhes do produto
 *
 * @param WP_Post $post Objeto do post atual
 */
function theme_espingardaria_product_details_callback($post) {
    wp_nonce_field('theme_espingardaria_product_details', 'theme_espingardaria_product_details_nonce');
    
    $price = get_post_meta($post->ID, '_preco', true);
    $regular_price = get_post_meta($post->ID, '_preco_regular', true);
    $sku = get_post_meta($post->ID, '_sku', true);
    $stock = get_post_meta($post->ID, '_estoque', true);
    $featured = get_post_meta($post->ID, '_destaque', true);
    
    ?>
    <div class="theme-espingardaria-product-fields">
        <div class="theme-espingardaria-product-field">
            <label for="theme_espingardaria_price"><?php esc_html_e('Preço', 'theme-espingardaria'); ?></label>
            <input type="text" id="theme_espingardaria_price" name="theme_espingardaria_price" value="<?php echo esc_attr($price); ?>">
        </div>
        
        <div class="theme-espingardaria-product-field">
            <label for="theme_espingardaria_regular_price"><?php esc_html_e('Preço Regular', 'theme-espingardaria'); ?></label>
            <input type="text" id="theme_espingardaria_regular_price" name="theme_espingardaria_regular_price" value="<?php echo esc_attr($regular_price); ?>">
            <p class="description"><?php esc_html_e('Preço antes do desconto, se aplicável.', 'theme-espingardaria'); ?></p>
        </div>
        
        <div class="theme-espingardaria-product-field">
            <label for="theme_espingardaria_sku"><?php esc_html_e('SKU', 'theme-espingardaria'); ?></label>
            <input type="text" id="theme_espingardaria_sku" name="theme_espingardaria_sku" value="<?php echo esc_attr($sku); ?>">
        </div>
        
        <div class="theme-espingardaria-product-field">
            <label for="theme_espingardaria_stock"><?php esc_html_e('Estoque', 'theme-espingardaria'); ?></label>
            <input type="number" id="theme_espingardaria_stock" name="theme_espingardaria_stock" value="<?php echo esc_attr($stock); ?>">
        </div>
        
        <div class="theme-espingardaria-product-field">
            <label for="theme_espingardaria_featured"><?php esc_html_e('Produto em Destaque', 'theme-espingardaria'); ?></label>
            <input type="checkbox" id="theme_espingardaria_featured" name="theme_espingardaria_featured" value="1" <?php checked($featured, '1'); ?>>
        </div>
    </div>
    <?php
}

/**
 * Salva os dados dos campos personalizados do produto
 *
 * @param int $post_id ID do post
 */
function theme_espingardaria_save_product_details($post_id) {
    if (!isset($_POST['theme_espingardaria_product_details_nonce']) || !wp_verify_nonce($_POST['theme_espingardaria_product_details_nonce'], 'theme_espingardaria_product_details')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    if (isset($_POST['theme_espingardaria_price'])) {
        update_post_meta($post_id, '_preco', sanitize_text_field($_POST['theme_espingardaria_price']));
    }
    
    if (isset($_POST['theme_espingardaria_regular_price'])) {
        update_post_meta($post_id, '_preco_regular', sanitize_text_field($_POST['theme_espingardaria_regular_price']));
    }
    
    if (isset($_POST['theme_espingardaria_sku'])) {
        update_post_meta($post_id, '_sku', sanitize_text_field($_POST['theme_espingardaria_sku']));
    }
    
    if (isset($_POST['theme_espingardaria_stock'])) {
        update_post_meta($post_id, '_estoque', intval($_POST['theme_espingardaria_stock']));
    }
    
    $featured = isset($_POST['theme_espingardaria_featured']) ? '1' : '0';
    update_post_meta($post_id, '_destaque', $featured);
}
add_action('save_post_produto', 'theme_espingardaria_save_product_details');

/**
 * Obtém as opções do tema
 *
 * @return array Opções do tema
 */
function theme_espingardaria_get_options() {
    return get_option('theme_espingardaria_options', array());
}

/**
 * Inclui os arquivos necessários
 */
require THEME_ESPINGARDARIA_DIR . '/inc/class-bootstrap-5-nav-walker.php';
require THEME_ESPINGARDARIA_DIR . '/inc/theme-options.php';
require THEME_ESPINGARDARIA_DIR . '/inc/customizer.php';

/**
 * Adiciona suporte para campos de imagem em taxonomias
 */
function theme_espingardaria_add_taxonomy_image_field() {
    $taxonomies = array('categoria-produto');
    
    foreach ($taxonomies as $taxonomy) {
        add_action($taxonomy . '_add_form_fields', 'theme_espingardaria_taxonomy_add_image_field');
        add_action($taxonomy . '_edit_form_fields', 'theme_espingardaria_taxonomy_edit_image_field');
        add_action('created_' . $taxonomy, 'theme_espingardaria_save_taxonomy_image');
        add_action('edited_' . $taxonomy, 'theme_espingardaria_save_taxonomy_image');
    }
}
add_action('admin_init', 'theme_espingardaria_add_taxonomy_image_field');

/**
 * Adiciona campo de imagem ao formulário de adição de taxonomia
 */
function theme_espingardaria_taxonomy_add_image_field() {
    ?>
    <div class="form-field term-group">
        <label for="taxonomy_image"><?php esc_html_e('Imagem', 'theme-espingardaria'); ?></label>
        <input type="hidden" id="taxonomy_image" name="taxonomy_image" class="custom_media_url" value="">
        <div id="taxonomy-image-wrapper"></div>
        <p>
            <input type="button" class="button button-secondary taxonomy_media_button" id="taxonomy_media_button" name="taxonomy_media_button" value="<?php esc_attr_e('Adicionar Imagem', 'theme-espingardaria'); ?>">
            <input type="button" class="button button-secondary taxonomy_media_remove" id="taxonomy_media_remove" name="taxonomy_media_remove" value="<?php esc_attr_e('Remover Imagem', 'theme-espingardaria'); ?>">
        </p>
    </div>
    <?php
}

/**
 * Adiciona campo de imagem ao formulário de edição de taxonomia
 *
 * @param WP_Term $term Objeto do termo atual
 */
function theme_espingardaria_taxonomy_edit_image_field($term) {
    $image_id = get_term_meta($term->term_id, 'thumbnail_id', true);
    $image = $image_id ? wp_get_attachment_image_url($image_id, 'thumbnail') : '';
    ?>
    <tr class="form-field term-group-wrap">
        <th scope="row">
            <label for="taxonomy_image"><?php esc_html_e('Imagem', 'theme-espingardaria'); ?></label>
        </th>
        <td>
            <input type="hidden" id="taxonomy_image" name="taxonomy_image" value="<?php echo esc_attr($image_id); ?>">
            <div id="taxonomy-image-wrapper">
                <?php if ($image) : ?>
                    <img src="<?php echo esc_url($image); ?>" alt="">
                <?php endif; ?>
            </div>
            <p>
                <input type="button" class="button button-secondary taxonomy_media_button" id="taxonomy_media_button" name="taxonomy_media_button" value="<?php esc_attr_e('Adicionar Imagem', 'theme-espingardaria'); ?>">
                <input type="button" class="button button-secondary taxonomy_media_remove" id="taxonomy_media_remove" name="taxonomy_media_remove" value="<?php esc_attr_e('Remover Imagem', 'theme-espingardaria'); ?>">
            </p>
        </td>
    </tr>
    <?php
}

/**
 * Salva a imagem da taxonomia
 *
 * @param int $term_id ID do termo
 */
function theme_espingardaria_save_taxonomy_image($term_id) {
    if (isset($_POST['taxonomy_image'])) {
        update_term_meta($term_id, 'thumbnail_id', absint($_POST['taxonomy_image']));
    }
}

/**
 * Enfileira scripts para o admin
 */
function theme_espingardaria_admin_scripts() {
    wp_enqueue_media();
    
    wp_enqueue_script('theme-espingardaria-admin-taxonomy', get_template_directory_uri() . '/js/admin-taxonomy.js', array('jquery'), THEME_ESPINGARDARIA_VERSION, true);
}
add_action('admin_enqueue_scripts', 'theme_espingardaria_admin_scripts');
