<?php
/**
 * Template para exibir a página inicial
 *
 * @package Theme_Espingardaria
 */

get_header();

// Obtém as opções do tema
$options = theme_espingardaria_get_options();
?>

<main id="primary" class="site-main">
    <?php
    // Banner Principal (Slider)
    if (isset($options['show_banner']) && !empty($options['slider'])) :
    ?>
    <section class="banner-section">
        <div id="mainSlider" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php
                $first = true;
                foreach ($options['slider'] as $slide) :
                    $active = $first ? ' active' : '';
                    $first = false;
                ?>
                <div class="carousel-item<?php echo esc_attr($active); ?>">
                    <?php if (!empty($slide['image'])) : ?>
                    <img src="<?php echo esc_url($slide['image']); ?>" class="d-block w-100" alt="<?php echo esc_attr($slide['title']); ?>">
                    <?php endif; ?>
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-8">
                                    <?php if (!empty($slide['title'])) : ?>
                                    <h1><?php echo esc_html($slide['title']); ?></h1>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($slide['subtitle'])) : ?>
                                    <p class="subtitle"><?php echo esc_html($slide['subtitle']); ?></p>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($slide['price'])) : ?>
                                    <div class="price"><?php echo esc_html($slide['price']); ?></div>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($slide['button_text']) && !empty($slide['button_url'])) : ?>
                                    <a href="<?php echo esc_url($slide['button_url']); ?>" class="btn btn-primary"><?php echo esc_html($slide['button_text']); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <button class="carousel-control-prev" type="button" data-bs-target="#mainSlider" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden"><?php esc_html_e('Anterior', 'theme-espingardaria'); ?></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#mainSlider" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden"><?php esc_html_e('Próximo', 'theme-espingardaria'); ?></span>
            </button>
        </div>
    </section>
    <?php endif; ?>
    
    <?php
    // Categorias de Produtos
    if (isset($options['show_categories'])) :
        $categories = array();
        
        if (isset($options['selected_categories']) && is_array($options['selected_categories'])) {
            $categories = get_terms(array(
                'taxonomy' => 'categoria-produto',
                'include' => $options['selected_categories'],
                'hide_empty' => false,
            ));
        } else {
            $categories = get_terms(array(
                'taxonomy' => 'categoria-produto',
                'hide_empty' => false,
                'number' => 6,
            ));
        }
        
        if (!empty($categories) && !is_wp_error($categories)) :
    ?>
    <section class="categories-section">
        <div class="container">
            <?php if (!empty($options['categories_title'])) : ?>
            <h2 class="section-title"><?php echo esc_html($options['categories_title']); ?></h2>
            <?php else : ?>
            <h2 class="section-title"><?php esc_html_e('Categorias', 'theme-espingardaria'); ?></h2>
            <?php endif; ?>
            
            <div class="row">
                <?php foreach ($categories as $category) : ?>
                <div class="col-6 col-md-4 col-lg-2">
                    <div class="category-item">
                        <a href="<?php echo esc_url(get_term_link($category)); ?>">
                            <?php
                            $thumbnail_id = get_term_meta($category->term_id, 'thumbnail_id', true);
                            if ($thumbnail_id) {
                                echo wp_get_attachment_image($thumbnail_id, 'thumbnail', false, array('class' => 'img-fluid'));
                            } else {
                                echo '<img src="' . esc_url(get_template_directory_uri() . '/images/placeholder.png') . '" alt="' . esc_attr($category->name) . '" class="img-fluid">';
                            }
                            ?>
                            <h3><?php echo esc_html($category->name); ?></h3>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
        endif;
    endif;
    ?>
    
    <?php
    // Produtos em Destaque
    if (isset($options['show_featured_products'])) :
        $featured_args = array(
            'post_type' => 'produto',
            'posts_per_page' => isset($options['featured_products_count']) ? intval($options['featured_products_count']) : 4,
            'meta_query' => array(
                array(
                    'key' => '_destaque',
                    'value' => '1',
                    'compare' => '=',
                ),
            ),
        );
        
        if (isset($options['featured_products_category']) && !empty($options['featured_products_category'])) {
            $featured_args['tax_query'] = array(
                array(
                    'taxonomy' => 'categoria-produto',
                    'field' => 'term_id',
                    'terms' => intval($options['featured_products_category']),
                ),
            );
        }
        
        $featured_query = new WP_Query($featured_args);
        
        if ($featured_query->have_posts()) :
    ?>
    <section class="featured-products-section">
        <div class="container">
            <?php if (!empty($options['featured_products_title'])) : ?>
            <h2 class="section-title"><?php echo esc_html($options['featured_products_title']); ?></h2>
            <?php else : ?>
            <h2 class="section-title"><?php esc_html_e('Produtos em Destaque', 'theme-espingardaria'); ?></h2>
            <?php endif; ?>
            
            <div class="row">
                <?php
                while ($featured_query->have_posts()) :
                    $featured_query->the_post();
                    $product_id = get_the_ID();
                    $price = get_post_meta($product_id, '_preco', true);
                    $regular_price = get_post_meta($product_id, '_preco_regular', true);
                ?>
                <div class="col-md-6 col-lg-3">
                    <div class="product-card">
                        <div class="product-image">
                            <a href="<?php the_permalink(); ?>">
                                <?php
                                if (has_post_thumbnail()) {
                                    the_post_thumbnail('theme-espingardaria-product', array('class' => 'img-fluid'));
                                } else {
                                    echo '<img src="' . esc_url(get_template_directory_uri() . '/images/placeholder.png') . '" alt="' . esc_attr(get_the_title()) . '" class="img-fluid">';
                                }
                                ?>
                            </a>
                            <?php if (!empty($regular_price) && !empty($price)) : ?>
                            <div class="product-badge">
                                <?php
                                $discount = (floatval($regular_price) - floatval($price)) / floatval($regular_price) * 100;
                                echo '<span class="badge bg-danger">' . round($discount) . '% OFF</span>';
                                ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="product-info">
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <div class="product-meta">
                                <?php
                                $marca = get_the_terms($product_id, 'marca');
                                if ($marca && !is_wp_error($marca)) {
                                    echo '<span class="product-brand">' . esc_html($marca[0]->name) . '</span>';
                                }
                                
                                $calibre = get_the_terms($product_id, 'calibre');
                                if ($calibre && !is_wp_error($calibre)) {
                                    echo '<span class="product-caliber">' . esc_html($calibre[0]->name) . '</span>';
                                }
                                ?>
                            </div>
                            <div class="product-price">
                                <?php if (!empty($regular_price) && !empty($price)) : ?>
                                <span class="regular-price"><?php echo 'R$ ' . esc_html($regular_price); ?></span>
                                <span class="sale-price"><?php echo 'R$ ' . esc_html($price); ?></span>
                                <?php elseif (!empty($price)) : ?>
                                <span class="price"><?php echo 'R$ ' . esc_html($price); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="product-rating">
                                <div class="stars">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star-half-alt"></i>
                                </div>
                                <span class="rating-count">(4.5)</span>
                            </div>
                            <div class="product-actions">
                                <a href="<?php the_permalink(); ?>" class="btn btn-primary"><?php esc_html_e('Ver Detalhes', 'theme-espingardaria'); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                endwhile;
                wp_reset_postdata();
                ?>
            </div>
        </div>
    </section>
    <?php
        endif;
    endif;
    ?>
    
    <?php
    // Seção de Treinamento
    if (isset($options['show_training'])) :
    ?>
    <section class="training-section" <?php if (!empty($options['training_image'])) : ?>style="background-image: url('<?php echo esc_url($options['training_image']); ?>');"<?php endif; ?>>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="training-content">
                        <?php if (!empty($options['training_title'])) : ?>
                        <h2><?php echo esc_html($options['training_title']); ?></h2>
                        <?php else : ?>
                        <h2><?php esc_html_e('Treinamento de Tiro', 'theme-espingardaria'); ?></h2>
                        <?php endif; ?>
                        
                        <?php if (!empty($options['training_text'])) : ?>
                        <div class="training-text"><?php echo wp_kses_post($options['training_text']); ?></div>
                        <?php endif; ?>
                        
                        <?php if (!empty($options['training_button_text']) && !empty($options['training_button_url'])) : ?>
                        <a href="<?php echo esc_url($options['training_button_url']); ?>" class="btn btn-primary"><?php echo esc_html($options['training_button_text']); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <?php
    // Seção de Munições
    if (isset($options['show_ammo'])) :
    ?>
    <section class="ammo-section" <?php if (!empty($options['ammo_image'])) : ?>style="background-image: url('<?php echo esc_url($options['ammo_image']); ?>');"<?php endif; ?>>
        <div class="container">
            <div class="row">
                <div class="col-md-6 offset-md-6">
                    <div class="ammo-content">
                        <?php if (!empty($options['ammo_title'])) : ?>
                        <h2><?php echo esc_html($options['ammo_title']); ?></h2>
                        <?php else : ?>
                        <h2><?php esc_html_e('Munições de Qualidade', 'theme-espingardaria'); ?></h2>
                        <?php endif; ?>
                        
                        <?php if (!empty($options['ammo_text'])) : ?>
                        <div class="ammo-text"><?php echo wp_kses_post($options['ammo_text']); ?></div>
                        <?php endif; ?>
                        
                        <?php if (!empty($options['ammo_button_text']) && !empty($options['ammo_button_url'])) : ?>
                        <a href="<?php echo esc_url($options['ammo_button_url']); ?>" class="btn btn-primary"><?php echo esc_html($options['ammo_button_text']); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <?php
    // Compre em Qualquer Lugar
    if (isset($options['show_shop_anywhere']) && isset($options['shop_anywhere_items']) && is_array($options['shop_anywhere_items'])) :
    ?>
    <section class="shop-anywhere-section">
        <div class="container">
            <?php if (!empty($options['shop_anywhere_title'])) : ?>
            <h2 class="section-title"><?php echo esc_html($options['shop_anywhere_title']); ?></h2>
            <?php else : ?>
            <h2 class="section-title"><?php esc_html_e('Compre em Qualquer Lugar', 'theme-espingardaria'); ?></h2>
            <?php endif; ?>
            
            <div class="row">
                <?php foreach ($options['shop_anywhere_items'] as $item) : ?>
                <div class="col-md-4">
                    <div class="shop-anywhere-item">
                        <a href="<?php echo esc_url($item['url']); ?>">
                            <?php if (!empty($item['image'])) : ?>
                            <img src="<?php echo esc_url($item['image']); ?>" alt="<?php echo esc_attr($item['title']); ?>" class="img-fluid">
                            <?php endif; ?>
                            <h3><?php echo esc_html($item['title']); ?></h3>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <?php
    // Avaliações de Clientes
    if (isset($options['show_reviews']) && isset($options['reviews']) && is_array($options['reviews'])) :
    ?>
    <section class="reviews-section">
        <div class="container">
            <?php if (!empty($options['reviews_title'])) : ?>
            <h2 class="section-title"><?php echo esc_html($options['reviews_title']); ?></h2>
            <?php else : ?>
            <h2 class="section-title"><?php esc_html_e('Avaliações de Clientes', 'theme-espingardaria'); ?></h2>
            <?php endif; ?>
            
            <div class="row">
                <?php foreach ($options['reviews'] as $review) : ?>
                <div class="col-md-4">
                    <div class="review-card">
                        <div class="review-rating">
                            <?php
                            $rating = isset($review['rating']) ? intval($review['rating']) : 5;
                            for ($i = 1; $i <= 5; $i++) {
                                if ($i <= $rating) {
                                    echo '<i class="fas fa-star"></i>';
                                } else {
                                    echo '<i class="far fa-star"></i>';
                                }
                            }
                            ?>
                        </div>
                        <div class="review-text">
                            <?php echo wp_kses_post($review['text']); ?>
                        </div>
                        <div class="review-author">
                            <?php if (!empty($review['image'])) : ?>
                            <div class="review-author-image">
                                <img src="<?php echo esc_url($review['image']); ?>" alt="<?php echo esc_attr($review['author']); ?>">
                            </div>
                            <?php endif; ?>
                            <div class="review-author-name">
                                <?php echo esc_html($review['author']); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <?php
    // Novos Produtos
    if (isset($options['show_new_products'])) :
        $new_args = array(
            'post_type' => 'produto',
            'posts_per_page' => isset($options['new_products_count']) ? intval($options['new_products_count']) : 4,
            'orderby' => 'date',
            'order' => 'DESC',
        );
        
        $new_query = new WP_Query($new_args);
        
        if ($new_query->have_posts()) :
    ?>
    <section class="new-products-section">
        <div class="container">
            <?php if (!empty($options['new_products_title'])) : ?>
            <h2 class="section-title"><?php echo esc_html($options['new_products_title']); ?></h2>
            <?php else : ?>
            <h2 class="section-title"><?php esc_html_e('Novos Produtos', 'theme-espingardaria'); ?></h2>
            <?php endif; ?>
            
            <div class="row">
                <?php
                while ($new_query->have_posts()) :
                    $new_query->the_post();
                    $product_id = get_the_ID();
                    $price = get_post_meta($product_id, '_preco', true);
                    $regular_price = get_post_meta($product_id, '_preco_regular', true);
                ?>
                <div class="col-md-6 col-lg-3">
                    <div class="product-card">
                        <div class="product-image">
                            <a href="<?php the_permalink(); ?>">
                                <?php
                                if (has_post_thumbnail()) {
                                    the_post_thumbnail('theme-espingardaria-product', array('class' => 'img-fluid'));
                                } else {
                                    echo '<img src="' . esc_url(get_template_directory_uri() . '/images/placeholder.png') . '" alt="' . esc_attr(get_the_title()) . '" class="img-fluid">';
                                }
                                ?>
                            </a>
                            <div class="product-badge">
                                <span class="badge bg-success"><?php esc_html_e('Novo', 'theme-espingardaria'); ?></span>
                            </div>
                        </div>
                        <div class="product-info">
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <div class="product-meta">
                                <?php
                                $marca = get_the_terms($product_id, 'marca');
                                if ($marca && !is_wp_error($marca)) {
                                    echo '<span class="product-brand">' . esc_html($marca[0]->name) . '</span>';
                                }
                                
                                $calibre = get_the_terms($product_id, 'calibre');
                                if ($calibre && !is_wp_error($calibre)) {
                                    echo '<span class="product-caliber">' . esc_html($calibre[0]->name) . '</span>';
                                }
                                ?>
                            </div>
                            <div class="product-price">
                                <?php if (!empty($regular_price) && !empty($price)) : ?>
                                <span class="regular-price"><?php echo 'R$ ' . esc_html($regular_price); ?></span>
                                <span class="sale-price"><?php echo 'R$ ' . esc_html($price); ?></span>
                                <?php elseif (!empty($price)) : ?>
                                <span class="price"><?php echo 'R$ ' . esc_html($price); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="product-actions">
                                <a href="<?php the_permalink(); ?>" class="btn btn-primary"><?php esc_html_e('Ver Detalhes', 'theme-espingardaria'); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                endwhile;
                wp_reset_postdata();
                ?>
            </div>
        </div>
    </section>
    <?php
        endif;
    endif;
    ?>
    
    <?php
    // Blog e Notícias
    if (isset($options['show_blog'])) :
        $blog_args = array(
            'post_type' => 'post',
            'posts_per_page' => isset($options['blog_count']) ? intval($options['blog_count']) : 3,
        );
        
        $blog_query = new WP_Query($blog_args);
        
        if ($blog_query->have_posts()) :
    ?>
    <section class="blog-section">
        <div class="container">
            <?php if (!empty($options['blog_title'])) : ?>
            <h2 class="section-title"><?php echo esc_html($options['blog_title']); ?></h2>
            <?php else : ?>
            <h2 class="section-title"><?php esc_html_e('Blog e Notícias', 'theme-espingardaria'); ?></h2>
            <?php endif; ?>
            
            <div class="row">
                <?php
                while ($blog_query->have_posts()) :
                    $blog_query->the_post();
                ?>
                <div class="col-md-4">
                    <div class="blog-card">
                        <div class="blog-image">
                            <a href="<?php the_permalink(); ?>">
                                <?php
                                if (has_post_thumbnail()) {
                                    the_post_thumbnail('theme-espingardaria-featured', array('class' => 'img-fluid'));
                                } else {
                                    echo '<img src="' . esc_url(get_template_directory_uri() . '/images/placeholder.png') . '" alt="' . esc_attr(get_the_title()) . '" class="img-fluid">';
                                }
                                ?>
                            </a>
                        </div>
                        <div class="blog-info">
                            <div class="blog-meta">
                                <span class="blog-date"><?php echo get_the_date(); ?></span>
                                <?php
                                $categories = get_the_category();
                                if (!empty($categories)) {
                                    echo '<span class="blog-category">' . esc_html($categories[0]->name) . '</span>';
                                }
                                ?>
                            </div>
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <div class="blog-excerpt">
                                <?php the_excerpt(); ?>
                            </div>
                            <div class="blog-actions">
                                <a href="<?php the_permalink(); ?>" class="btn btn-link"><?php esc_html_e('Leia Mais', 'theme-espingardaria'); ?> <i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                endwhile;
                wp_reset_postdata();
                ?>
            </div>
        </div>
    </section>
    <?php
        endif;
    endif;
    ?>
    
    <?php
    // Sobre Nós
    if (isset($options['show_about'])) :
    ?>
    <section class="about-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="about-content">
                        <?php if (!empty($options['about_title'])) : ?>
                        <h2><?php echo esc_html($options['about_title']); ?></h2>
                        <?php else : ?>
                        <h2><?php esc_html_e('Sobre Nós', 'theme-espingardaria'); ?></h2>
                        <?php endif; ?>
                        
                        <?php if (!empty($options['about_text'])) : ?>
                        <div class="about-text"><?php echo wp_kses_post($options['about_text']); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <?php if (!empty($options['about_image'])) : ?>
                    <div class="about-image">
                        <img src="<?php echo esc_url($options['about_image']); ?>" alt="<?php esc_attr_e('Sobre Nós', 'theme-espingardaria'); ?>" class="img-fluid">
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
</main>

<?php
get_footer();
