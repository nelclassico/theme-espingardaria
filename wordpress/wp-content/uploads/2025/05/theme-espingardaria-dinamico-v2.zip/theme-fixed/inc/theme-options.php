<?php
/**
 * Implementação do painel de opções do tema
 *
 * @package Theme_Espingardaria
 */

if (!defined('ABSPATH')) {
    exit; // Saída direta se acessado diretamente
}

/**
 * Classe para gerenciar as opções do tema
 */
class Theme_Espingardaria_Options {
    /**
     * Opções do tema
     *
     * @var array
     */
    private $options;

    /**
     * Construtor
     */
    public function __construct() {
        $this->options = get_option('theme_espingardaria_options', array());
        
        add_action('admin_menu', array($this, 'add_theme_options_page'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }

    /**
     * Adiciona a página de opções do tema ao menu
     */
    public function add_theme_options_page() {
        add_theme_page(
            __('Opções do Tema', 'theme-espingardaria'),
            __('Opções do Tema', 'theme-espingardaria'),
            'manage_options',
            'theme-espingardaria-options',
            array($this, 'render_options_page')
        );
    }

    /**
     * Registra as configurações do tema
     */
    public function register_settings() {
        register_setting(
            'theme_espingardaria_options_group',
            'theme_espingardaria_options',
            array($this, 'sanitize_options')
        );
    }

    /**
     * Sanitiza as opções do tema
     *
     * @param array $input Opções enviadas pelo formulário
     * @return array Opções sanitizadas
     */
    public function sanitize_options($input) {
        $output = array();
        
        // Banner Principal (Slider)
        if (isset($input['show_banner'])) {
            $output['show_banner'] = true;
        }
        
        if (isset($input['slider']) && is_array($input['slider'])) {
            foreach ($input['slider'] as $key => $slide) {
                $output['slider'][$key]['image'] = esc_url_raw($slide['image']);
                $output['slider'][$key]['title'] = sanitize_text_field($slide['title']);
                $output['slider'][$key]['subtitle'] = sanitize_text_field($slide['subtitle']);
                $output['slider'][$key]['price'] = sanitize_text_field($slide['price']);
                $output['slider'][$key]['button_text'] = sanitize_text_field($slide['button_text']);
                $output['slider'][$key]['button_url'] = esc_url_raw($slide['button_url']);
            }
        }
        
        // Categorias de Produtos
        if (isset($input['show_categories'])) {
            $output['show_categories'] = true;
        }
        
        $output['categories_title'] = isset($input['categories_title']) ? sanitize_text_field($input['categories_title']) : '';
        
        if (isset($input['selected_categories']) && is_array($input['selected_categories'])) {
            $output['selected_categories'] = array_map('intval', $input['selected_categories']);
        }
        
        // Produtos em Destaque
        if (isset($input['show_featured_products'])) {
            $output['show_featured_products'] = true;
        }
        
        $output['featured_products_title'] = isset($input['featured_products_title']) ? sanitize_text_field($input['featured_products_title']) : '';
        $output['featured_products_count'] = isset($input['featured_products_count']) ? intval($input['featured_products_count']) : 4;
        
        if (isset($input['featured_products_category'])) {
            $output['featured_products_category'] = intval($input['featured_products_category']);
        }
        
        // Seção de Treinamento
        if (isset($input['show_training'])) {
            $output['show_training'] = true;
        }
        
        $output['training_title'] = isset($input['training_title']) ? sanitize_text_field($input['training_title']) : '';
        $output['training_text'] = isset($input['training_text']) ? wp_kses_post($input['training_text']) : '';
        $output['training_button_text'] = isset($input['training_button_text']) ? sanitize_text_field($input['training_button_text']) : '';
        $output['training_button_url'] = isset($input['training_button_url']) ? esc_url_raw($input['training_button_url']) : '';
        $output['training_image'] = isset($input['training_image']) ? esc_url_raw($input['training_image']) : '';
        
        // Seção de Munições
        if (isset($input['show_ammo'])) {
            $output['show_ammo'] = true;
        }
        
        $output['ammo_title'] = isset($input['ammo_title']) ? sanitize_text_field($input['ammo_title']) : '';
        $output['ammo_text'] = isset($input['ammo_text']) ? wp_kses_post($input['ammo_text']) : '';
        $output['ammo_button_text'] = isset($input['ammo_button_text']) ? sanitize_text_field($input['ammo_button_text']) : '';
        $output['ammo_button_url'] = isset($input['ammo_button_url']) ? esc_url_raw($input['ammo_button_url']) : '';
        $output['ammo_image'] = isset($input['ammo_image']) ? esc_url_raw($input['ammo_image']) : '';
        
        // Compre em Qualquer Lugar
        if (isset($input['show_shop_anywhere'])) {
            $output['show_shop_anywhere'] = true;
        }
        
        $output['shop_anywhere_title'] = isset($input['shop_anywhere_title']) ? sanitize_text_field($input['shop_anywhere_title']) : '';
        
        if (isset($input['shop_anywhere_items']) && is_array($input['shop_anywhere_items'])) {
            foreach ($input['shop_anywhere_items'] as $key => $item) {
                $output['shop_anywhere_items'][$key]['image'] = esc_url_raw($item['image']);
                $output['shop_anywhere_items'][$key]['title'] = sanitize_text_field($item['title']);
                $output['shop_anywhere_items'][$key]['url'] = esc_url_raw($item['url']);
            }
        }
        
        // Avaliações de Clientes
        if (isset($input['show_reviews'])) {
            $output['show_reviews'] = true;
        }
        
        $output['reviews_title'] = isset($input['reviews_title']) ? sanitize_text_field($input['reviews_title']) : '';
        
        if (isset($input['reviews']) && is_array($input['reviews'])) {
            foreach ($input['reviews'] as $key => $review) {
                $output['reviews'][$key]['text'] = wp_kses_post($review['text']);
                $output['reviews'][$key]['author'] = sanitize_text_field($review['author']);
                $output['reviews'][$key]['rating'] = intval($review['rating']);
                $output['reviews'][$key]['image'] = esc_url_raw($review['image']);
            }
        }
        
        // Novos Produtos
        if (isset($input['show_new_products'])) {
            $output['show_new_products'] = true;
        }
        
        $output['new_products_title'] = isset($input['new_products_title']) ? sanitize_text_field($input['new_products_title']) : '';
        $output['new_products_count'] = isset($input['new_products_count']) ? intval($input['new_products_count']) : 4;
        
        // Blog e Notícias
        if (isset($input['show_blog'])) {
            $output['show_blog'] = true;
        }
        
        $output['blog_title'] = isset($input['blog_title']) ? sanitize_text_field($input['blog_title']) : '';
        $output['blog_count'] = isset($input['blog_count']) ? intval($input['blog_count']) : 3;
        
        // Sobre Nós
        if (isset($input['show_about'])) {
            $output['show_about'] = true;
        }
        
        $output['about_title'] = isset($input['about_title']) ? sanitize_text_field($input['about_title']) : '';
        $output['about_text'] = isset($input['about_text']) ? wp_kses_post($input['about_text']) : '';
        $output['about_image'] = isset($input['about_image']) ? esc_url_raw($input['about_image']) : '';
        
        return $output;
    }

    /**
     * Carrega os scripts e estilos para o painel de administração
     *
     * @param string $hook Hook atual
     */
    public function enqueue_admin_scripts($hook) {
        if ('appearance_page_theme-espingardaria-options' !== $hook) {
            return;
        }
        
        wp_enqueue_media();
        
        wp_enqueue_style('theme-espingardaria-admin', get_template_directory_uri() . '/css/admin.css', array(), '1.0.0');
        
        wp_enqueue_script('jquery-ui-sortable');
        wp_enqueue_script('theme-espingardaria-admin', get_template_directory_uri() . '/js/admin.js', array('jquery', 'jquery-ui-sortable'), '1.0.0', true);
        
        wp_localize_script('theme-espingardaria-admin', 'themeEspingardaria', array(
            'mediaTitle' => __('Selecionar ou Enviar Imagem', 'theme-espingardaria'),
            'mediaButton' => __('Usar esta imagem', 'theme-espingardaria'),
            'removeText' => __('Remover', 'theme-espingardaria'),
            'addText' => __('Adicionar', 'theme-espingardaria'),
        ));
    }

    /**
     * Renderiza a página de opções do tema
     */
    public function render_options_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('theme_espingardaria_options_group'); ?>
                
                <div class="theme-options-tabs">
                    <ul class="theme-options-tabs-nav">
                        <li class="active"><a href="#tab-home"><?php esc_html_e('Home Page', 'theme-espingardaria'); ?></a></li>
                        <li><a href="#tab-header"><?php esc_html_e('Header', 'theme-espingardaria'); ?></a></li>
                        <li><a href="#tab-footer"><?php esc_html_e('Footer', 'theme-espingardaria'); ?></a></li>
                        <li><a href="#tab-social"><?php esc_html_e('Redes Sociais', 'theme-espingardaria'); ?></a></li>
                        <li><a href="#tab-advanced"><?php esc_html_e('Avançado', 'theme-espingardaria'); ?></a></li>
                    </ul>
                    
                    <div class="theme-options-tabs-content">
                        <div id="tab-home" class="theme-options-tab active">
                            <?php $this->render_home_options(); ?>
                        </div>
                        
                        <div id="tab-header" class="theme-options-tab">
                            <?php $this->render_header_options(); ?>
                        </div>
                        
                        <div id="tab-footer" class="theme-options-tab">
                            <?php $this->render_footer_options(); ?>
                        </div>
                        
                        <div id="tab-social" class="theme-options-tab">
                            <?php $this->render_social_options(); ?>
                        </div>
                        
                        <div id="tab-advanced" class="theme-options-tab">
                            <?php $this->render_advanced_options(); ?>
                        </div>
                    </div>
                </div>
                
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    /**
     * Renderiza as opções da home page
     */
    public function render_home_options() {
        ?>
        <div class="theme-options-accordion">
            <!-- Banner Principal (Slider) -->
            <div class="theme-options-section">
                <div class="theme-options-section-header">
                    <h3><?php esc_html_e('Banner Principal (Slider)', 'theme-espingardaria'); ?></h3>
                    <div class="theme-options-section-toggle">
                        <label class="switch">
                            <input type="checkbox" name="theme_espingardaria_options[show_banner]" <?php checked(isset($this->options['show_banner'])); ?>>
                            <span class="slider round"></span>
                        </label>
                    </div>
                </div>
                
                <div class="theme-options-section-content">
                    <div class="theme-options-sortable-wrapper">
                        <div class="theme-options-sortable-header">
                            <h4><?php esc_html_e('Slides', 'theme-espingardaria'); ?></h4>
                            <button type="button" class="button add-slide"><?php esc_html_e('Adicionar Slide', 'theme-espingardaria'); ?></button>
                        </div>
                        
                        <ul class="theme-options-sortable slides-sortable">
                            <?php
                            if (isset($this->options['slider']) && is_array($this->options['slider'])) {
                                foreach ($this->options['slider'] as $index => $slide) {
                                    ?>
                                    <li class="theme-options-sortable-item">
                                        <div class="theme-options-sortable-item-header">
                                            <span class="theme-options-sortable-item-title"><?php echo esc_html($slide['title']); ?></span>
                                            <div class="theme-options-sortable-item-actions">
                                                <button type="button" class="theme-options-sortable-item-toggle"><span class="dashicons dashicons-arrow-down"></span></button>
                                                <button type="button" class="theme-options-sortable-item-remove"><span class="dashicons dashicons-trash"></span></button>
                                            </div>
                                        </div>
                                        
                                        <div class="theme-options-sortable-item-content">
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('Imagem', 'theme-espingardaria'); ?></label>
                                                <div class="media-uploader">
                                                    <input type="hidden" name="theme_espingardaria_options[slider][<?php echo $index; ?>][image]" value="<?php echo esc_attr($slide['image']); ?>">
                                                    <div class="media-preview">
                                                        <?php if (!empty($slide['image'])) : ?>
                                                            <img src="<?php echo esc_url($slide['image']); ?>" alt="">
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="media-buttons">
                                                        <button type="button" class="button upload-media"><?php esc_html_e('Selecionar Imagem', 'theme-espingardaria'); ?></button>
                                                        <button type="button" class="button remove-media"><?php esc_html_e('Remover Imagem', 'theme-espingardaria'); ?></button>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('Título', 'theme-espingardaria'); ?></label>
                                                <input type="text" name="theme_espingardaria_options[slider][<?php echo $index; ?>][title]" value="<?php echo esc_attr($slide['title']); ?>">
                                            </div>
                                            
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('Subtítulo', 'theme-espingardaria'); ?></label>
                                                <input type="text" name="theme_espingardaria_options[slider][<?php echo $index; ?>][subtitle]" value="<?php echo esc_attr($slide['subtitle']); ?>">
                                            </div>
                                            
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('Preço', 'theme-espingardaria'); ?></label>
                                                <input type="text" name="theme_espingardaria_options[slider][<?php echo $index; ?>][price]" value="<?php echo esc_attr($slide['price']); ?>">
                                            </div>
                                            
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('Texto do Botão', 'theme-espingardaria'); ?></label>
                                                <input type="text" name="theme_espingardaria_options[slider][<?php echo $index; ?>][button_text]" value="<?php echo esc_attr($slide['button_text']); ?>">
                                            </div>
                                            
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('URL do Botão', 'theme-espingardaria'); ?></label>
                                                <input type="text" name="theme_espingardaria_options[slider][<?php echo $index; ?>][button_url]" value="<?php echo esc_attr($slide['button_url']); ?>">
                                            </div>
                                        </div>
                                    </li>
                                    <?php
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Categorias de Produtos -->
            <div class="theme-options-section">
                <div class="theme-options-section-header">
                    <h3><?php esc_html_e('Categorias de Produtos', 'theme-espingardaria'); ?></h3>
                    <div class="theme-options-section-toggle">
                        <label class="switch">
                            <input type="checkbox" name="theme_espingardaria_options[show_categories]" <?php checked(isset($this->options['show_categories'])); ?>>
                            <span class="slider round"></span>
                        </label>
                    </div>
                </div>
                
                <div class="theme-options-section-content">
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Título da Seção', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[categories_title]" value="<?php echo esc_attr(isset($this->options['categories_title']) ? $this->options['categories_title'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Categorias Selecionadas', 'theme-espingardaria'); ?></label>
                        <?php
                        $categories = get_terms(array(
                            'taxonomy' => 'categoria-produto',
                            'hide_empty' => false,
                        ));
                        
                        if (!empty($categories) && !is_wp_error($categories)) {
                            echo '<div class="theme-options-checkboxes">';
                            foreach ($categories as $category) {
                                $checked = isset($this->options['selected_categories']) && in_array($category->term_id, $this->options['selected_categories']) ? 'checked' : '';
                                echo '<label><input type="checkbox" name="theme_espingardaria_options[selected_categories][]" value="' . esc_attr($category->term_id) . '" ' . $checked . '> ' . esc_html($category->name) . '</label>';
                            }
                            echo '</div>';
                        } else {
                            echo '<p>' . esc_html__('Nenhuma categoria encontrada.', 'theme-espingardaria') . '</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>
            
            <!-- Produtos em Destaque -->
            <div class="theme-options-section">
                <div class="theme-options-section-header">
                    <h3><?php esc_html_e('Produtos em Destaque', 'theme-espingardaria'); ?></h3>
                    <div class="theme-options-section-toggle">
                        <label class="switch">
                            <input type="checkbox" name="theme_espingardaria_options[show_featured_products]" <?php checked(isset($this->options['show_featured_products'])); ?>>
                            <span class="slider round"></span>
                        </label>
                    </div>
                </div>
                
                <div class="theme-options-section-content">
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Título da Seção', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[featured_products_title]" value="<?php echo esc_attr(isset($this->options['featured_products_title']) ? $this->options['featured_products_title'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Categoria', 'theme-espingardaria'); ?></label>
                        <select name="theme_espingardaria_options[featured_products_category]">
                            <option value=""><?php esc_html_e('Todas as Categorias', 'theme-espingardaria'); ?></option>
                            <?php
                            $categories = get_terms(array(
                                'taxonomy' => 'categoria-produto',
                                'hide_empty' => false,
                            ));
                            
                            if (!empty($categories) && !is_wp_error($categories)) {
                                foreach ($categories as $category) {
                                    $selected = isset($this->options['featured_products_category']) && $this->options['featured_products_category'] == $category->term_id ? 'selected' : '';
                                    echo '<option value="' . esc_attr($category->term_id) . '" ' . $selected . '>' . esc_html($category->name) . '</option>';
                                }
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Quantidade de Produtos', 'theme-espingardaria'); ?></label>
                        <input type="number" name="theme_espingardaria_options[featured_products_count]" value="<?php echo esc_attr(isset($this->options['featured_products_count']) ? $this->options['featured_products_count'] : 4); ?>" min="1" max="12">
                    </div>
                </div>
            </div>
            
            <!-- Seção de Treinamento -->
            <div class="theme-options-section">
                <div class="theme-options-section-header">
                    <h3><?php esc_html_e('Seção de Treinamento', 'theme-espingardaria'); ?></h3>
                    <div class="theme-options-section-toggle">
                        <label class="switch">
                            <input type="checkbox" name="theme_espingardaria_options[show_training]" <?php checked(isset($this->options['show_training'])); ?>>
                            <span class="slider round"></span>
                        </label>
                    </div>
                </div>
                
                <div class="theme-options-section-content">
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Título', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[training_title]" value="<?php echo esc_attr(isset($this->options['training_title']) ? $this->options['training_title'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Texto', 'theme-espingardaria'); ?></label>
                        <textarea name="theme_espingardaria_options[training_text]" rows="5"><?php echo esc_textarea(isset($this->options['training_text']) ? $this->options['training_text'] : ''); ?></textarea>
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Texto do Botão', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[training_button_text]" value="<?php echo esc_attr(isset($this->options['training_button_text']) ? $this->options['training_button_text'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('URL do Botão', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[training_button_url]" value="<?php echo esc_attr(isset($this->options['training_button_url']) ? $this->options['training_button_url'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Imagem de Fundo', 'theme-espingardaria'); ?></label>
                        <div class="media-uploader">
                            <input type="hidden" name="theme_espingardaria_options[training_image]" value="<?php echo esc_attr(isset($this->options['training_image']) ? $this->options['training_image'] : ''); ?>">
                            <div class="media-preview">
                                <?php if (!empty($this->options['training_image'])) : ?>
                                    <img src="<?php echo esc_url($this->options['training_image']); ?>" alt="">
                                <?php endif; ?>
                            </div>
                            <div class="media-buttons">
                                <button type="button" class="button upload-media"><?php esc_html_e('Selecionar Imagem', 'theme-espingardaria'); ?></button>
                                <button type="button" class="button remove-media"><?php esc_html_e('Remover Imagem', 'theme-espingardaria'); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Seção de Munições -->
            <div class="theme-options-section">
                <div class="theme-options-section-header">
                    <h3><?php esc_html_e('Seção de Munições', 'theme-espingardaria'); ?></h3>
                    <div class="theme-options-section-toggle">
                        <label class="switch">
                            <input type="checkbox" name="theme_espingardaria_options[show_ammo]" <?php checked(isset($this->options['show_ammo'])); ?>>
                            <span class="slider round"></span>
                        </label>
                    </div>
                </div>
                
                <div class="theme-options-section-content">
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Título', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[ammo_title]" value="<?php echo esc_attr(isset($this->options['ammo_title']) ? $this->options['ammo_title'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Texto', 'theme-espingardaria'); ?></label>
                        <textarea name="theme_espingardaria_options[ammo_text]" rows="5"><?php echo esc_textarea(isset($this->options['ammo_text']) ? $this->options['ammo_text'] : ''); ?></textarea>
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Texto do Botão', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[ammo_button_text]" value="<?php echo esc_attr(isset($this->options['ammo_button_text']) ? $this->options['ammo_button_text'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('URL do Botão', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[ammo_button_url]" value="<?php echo esc_attr(isset($this->options['ammo_button_url']) ? $this->options['ammo_button_url'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Imagem de Fundo', 'theme-espingardaria'); ?></label>
                        <div class="media-uploader">
                            <input type="hidden" name="theme_espingardaria_options[ammo_image]" value="<?php echo esc_attr(isset($this->options['ammo_image']) ? $this->options['ammo_image'] : ''); ?>">
                            <div class="media-preview">
                                <?php if (!empty($this->options['ammo_image'])) : ?>
                                    <img src="<?php echo esc_url($this->options['ammo_image']); ?>" alt="">
                                <?php endif; ?>
                            </div>
                            <div class="media-buttons">
                                <button type="button" class="button upload-media"><?php esc_html_e('Selecionar Imagem', 'theme-espingardaria'); ?></button>
                                <button type="button" class="button remove-media"><?php esc_html_e('Remover Imagem', 'theme-espingardaria'); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Compre em Qualquer Lugar -->
            <div class="theme-options-section">
                <div class="theme-options-section-header">
                    <h3><?php esc_html_e('Compre em Qualquer Lugar', 'theme-espingardaria'); ?></h3>
                    <div class="theme-options-section-toggle">
                        <label class="switch">
                            <input type="checkbox" name="theme_espingardaria_options[show_shop_anywhere]" <?php checked(isset($this->options['show_shop_anywhere'])); ?>>
                            <span class="slider round"></span>
                        </label>
                    </div>
                </div>
                
                <div class="theme-options-section-content">
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Título da Seção', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[shop_anywhere_title]" value="<?php echo esc_attr(isset($this->options['shop_anywhere_title']) ? $this->options['shop_anywhere_title'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-sortable-wrapper">
                        <div class="theme-options-sortable-header">
                            <h4><?php esc_html_e('Itens', 'theme-espingardaria'); ?></h4>
                            <button type="button" class="button add-shop-item"><?php esc_html_e('Adicionar Item', 'theme-espingardaria'); ?></button>
                        </div>
                        
                        <ul class="theme-options-sortable shop-items-sortable">
                            <?php
                            if (isset($this->options['shop_anywhere_items']) && is_array($this->options['shop_anywhere_items'])) {
                                foreach ($this->options['shop_anywhere_items'] as $index => $item) {
                                    ?>
                                    <li class="theme-options-sortable-item">
                                        <div class="theme-options-sortable-item-header">
                                            <span class="theme-options-sortable-item-title"><?php echo esc_html($item['title']); ?></span>
                                            <div class="theme-options-sortable-item-actions">
                                                <button type="button" class="theme-options-sortable-item-toggle"><span class="dashicons dashicons-arrow-down"></span></button>
                                                <button type="button" class="theme-options-sortable-item-remove"><span class="dashicons dashicons-trash"></span></button>
                                            </div>
                                        </div>
                                        
                                        <div class="theme-options-sortable-item-content">
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('Imagem', 'theme-espingardaria'); ?></label>
                                                <div class="media-uploader">
                                                    <input type="hidden" name="theme_espingardaria_options[shop_anywhere_items][<?php echo $index; ?>][image]" value="<?php echo esc_attr($item['image']); ?>">
                                                    <div class="media-preview">
                                                        <?php if (!empty($item['image'])) : ?>
                                                            <img src="<?php echo esc_url($item['image']); ?>" alt="">
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="media-buttons">
                                                        <button type="button" class="button upload-media"><?php esc_html_e('Selecionar Imagem', 'theme-espingardaria'); ?></button>
                                                        <button type="button" class="button remove-media"><?php esc_html_e('Remover Imagem', 'theme-espingardaria'); ?></button>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('Título', 'theme-espingardaria'); ?></label>
                                                <input type="text" name="theme_espingardaria_options[shop_anywhere_items][<?php echo $index; ?>][title]" value="<?php echo esc_attr($item['title']); ?>">
                                            </div>
                                            
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('URL', 'theme-espingardaria'); ?></label>
                                                <input type="text" name="theme_espingardaria_options[shop_anywhere_items][<?php echo $index; ?>][url]" value="<?php echo esc_attr($item['url']); ?>">
                                            </div>
                                        </div>
                                    </li>
                                    <?php
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Avaliações de Clientes -->
            <div class="theme-options-section">
                <div class="theme-options-section-header">
                    <h3><?php esc_html_e('Avaliações de Clientes', 'theme-espingardaria'); ?></h3>
                    <div class="theme-options-section-toggle">
                        <label class="switch">
                            <input type="checkbox" name="theme_espingardaria_options[show_reviews]" <?php checked(isset($this->options['show_reviews'])); ?>>
                            <span class="slider round"></span>
                        </label>
                    </div>
                </div>
                
                <div class="theme-options-section-content">
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Título da Seção', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[reviews_title]" value="<?php echo esc_attr(isset($this->options['reviews_title']) ? $this->options['reviews_title'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-sortable-wrapper">
                        <div class="theme-options-sortable-header">
                            <h4><?php esc_html_e('Avaliações', 'theme-espingardaria'); ?></h4>
                            <button type="button" class="button add-review"><?php esc_html_e('Adicionar Avaliação', 'theme-espingardaria'); ?></button>
                        </div>
                        
                        <ul class="theme-options-sortable reviews-sortable">
                            <?php
                            if (isset($this->options['reviews']) && is_array($this->options['reviews'])) {
                                foreach ($this->options['reviews'] as $index => $review) {
                                    ?>
                                    <li class="theme-options-sortable-item">
                                        <div class="theme-options-sortable-item-header">
                                            <span class="theme-options-sortable-item-title"><?php echo esc_html($review['author']); ?></span>
                                            <div class="theme-options-sortable-item-actions">
                                                <button type="button" class="theme-options-sortable-item-toggle"><span class="dashicons dashicons-arrow-down"></span></button>
                                                <button type="button" class="theme-options-sortable-item-remove"><span class="dashicons dashicons-trash"></span></button>
                                            </div>
                                        </div>
                                        
                                        <div class="theme-options-sortable-item-content">
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('Texto da Avaliação', 'theme-espingardaria'); ?></label>
                                                <textarea name="theme_espingardaria_options[reviews][<?php echo $index; ?>][text]" rows="5"><?php echo esc_textarea($review['text']); ?></textarea>
                                            </div>
                                            
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('Nome do Autor', 'theme-espingardaria'); ?></label>
                                                <input type="text" name="theme_espingardaria_options[reviews][<?php echo $index; ?>][author]" value="<?php echo esc_attr($review['author']); ?>">
                                            </div>
                                            
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('Avaliação (1-5)', 'theme-espingardaria'); ?></label>
                                                <input type="number" name="theme_espingardaria_options[reviews][<?php echo $index; ?>][rating]" value="<?php echo esc_attr($review['rating']); ?>" min="1" max="5">
                                            </div>
                                            
                                            <div class="theme-options-field">
                                                <label><?php esc_html_e('Imagem do Autor', 'theme-espingardaria'); ?></label>
                                                <div class="media-uploader">
                                                    <input type="hidden" name="theme_espingardaria_options[reviews][<?php echo $index; ?>][image]" value="<?php echo esc_attr($review['image']); ?>">
                                                    <div class="media-preview">
                                                        <?php if (!empty($review['image'])) : ?>
                                                            <img src="<?php echo esc_url($review['image']); ?>" alt="">
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="media-buttons">
                                                        <button type="button" class="button upload-media"><?php esc_html_e('Selecionar Imagem', 'theme-espingardaria'); ?></button>
                                                        <button type="button" class="button remove-media"><?php esc_html_e('Remover Imagem', 'theme-espingardaria'); ?></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <?php
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Novos Produtos -->
            <div class="theme-options-section">
                <div class="theme-options-section-header">
                    <h3><?php esc_html_e('Novos Produtos', 'theme-espingardaria'); ?></h3>
                    <div class="theme-options-section-toggle">
                        <label class="switch">
                            <input type="checkbox" name="theme_espingardaria_options[show_new_products]" <?php checked(isset($this->options['show_new_products'])); ?>>
                            <span class="slider round"></span>
                        </label>
                    </div>
                </div>
                
                <div class="theme-options-section-content">
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Título da Seção', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[new_products_title]" value="<?php echo esc_attr(isset($this->options['new_products_title']) ? $this->options['new_products_title'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Quantidade de Produtos', 'theme-espingardaria'); ?></label>
                        <input type="number" name="theme_espingardaria_options[new_products_count]" value="<?php echo esc_attr(isset($this->options['new_products_count']) ? $this->options['new_products_count'] : 4); ?>" min="1" max="12">
                    </div>
                </div>
            </div>
            
            <!-- Blog e Notícias -->
            <div class="theme-options-section">
                <div class="theme-options-section-header">
                    <h3><?php esc_html_e('Blog e Notícias', 'theme-espingardaria'); ?></h3>
                    <div class="theme-options-section-toggle">
                        <label class="switch">
                            <input type="checkbox" name="theme_espingardaria_options[show_blog]" <?php checked(isset($this->options['show_blog'])); ?>>
                            <span class="slider round"></span>
                        </label>
                    </div>
                </div>
                
                <div class="theme-options-section-content">
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Título da Seção', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[blog_title]" value="<?php echo esc_attr(isset($this->options['blog_title']) ? $this->options['blog_title'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Quantidade de Posts', 'theme-espingardaria'); ?></label>
                        <input type="number" name="theme_espingardaria_options[blog_count]" value="<?php echo esc_attr(isset($this->options['blog_count']) ? $this->options['blog_count'] : 3); ?>" min="1" max="12">
                    </div>
                </div>
            </div>
            
            <!-- Sobre Nós -->
            <div class="theme-options-section">
                <div class="theme-options-section-header">
                    <h3><?php esc_html_e('Sobre Nós', 'theme-espingardaria'); ?></h3>
                    <div class="theme-options-section-toggle">
                        <label class="switch">
                            <input type="checkbox" name="theme_espingardaria_options[show_about]" <?php checked(isset($this->options['show_about'])); ?>>
                            <span class="slider round"></span>
                        </label>
                    </div>
                </div>
                
                <div class="theme-options-section-content">
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Título da Seção', 'theme-espingardaria'); ?></label>
                        <input type="text" name="theme_espingardaria_options[about_title]" value="<?php echo esc_attr(isset($this->options['about_title']) ? $this->options['about_title'] : ''); ?>">
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Texto', 'theme-espingardaria'); ?></label>
                        <textarea name="theme_espingardaria_options[about_text]" rows="5"><?php echo esc_textarea(isset($this->options['about_text']) ? $this->options['about_text'] : ''); ?></textarea>
                    </div>
                    
                    <div class="theme-options-field">
                        <label><?php esc_html_e('Imagem', 'theme-espingardaria'); ?></label>
                        <div class="media-uploader">
                            <input type="hidden" name="theme_espingardaria_options[about_image]" value="<?php echo esc_attr(isset($this->options['about_image']) ? $this->options['about_image'] : ''); ?>">
                            <div class="media-preview">
                                <?php if (!empty($this->options['about_image'])) : ?>
                                    <img src="<?php echo esc_url($this->options['about_image']); ?>" alt="">
                                <?php endif; ?>
                            </div>
                            <div class="media-buttons">
                                <button type="button" class="button upload-media"><?php esc_html_e('Selecionar Imagem', 'theme-espingardaria'); ?></button>
                                <button type="button" class="button remove-media"><?php esc_html_e('Remover Imagem', 'theme-espingardaria'); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Renderiza as opções do cabeçalho
     */
    public function render_header_options() {
        ?>
        <div class="theme-options-field">
            <label><?php esc_html_e('Telefone', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[header_phone]" value="<?php echo esc_attr(isset($this->options['header_phone']) ? $this->options['header_phone'] : ''); ?>">
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('Email', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[header_email]" value="<?php echo esc_attr(isset($this->options['header_email']) ? $this->options['header_email'] : ''); ?>">
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('Endereço', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[header_address]" value="<?php echo esc_attr(isset($this->options['header_address']) ? $this->options['header_address'] : ''); ?>">
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('Horário de Funcionamento', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[header_hours]" value="<?php echo esc_attr(isset($this->options['header_hours']) ? $this->options['header_hours'] : ''); ?>">
        </div>
        <?php
    }

    /**
     * Renderiza as opções do rodapé
     */
    public function render_footer_options() {
        ?>
        <div class="theme-options-field">
            <label><?php esc_html_e('Texto do Rodapé', 'theme-espingardaria'); ?></label>
            <textarea name="theme_espingardaria_options[footer_text]" rows="5"><?php echo esc_textarea(isset($this->options['footer_text']) ? $this->options['footer_text'] : ''); ?></textarea>
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('Texto de Copyright', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[footer_copyright]" value="<?php echo esc_attr(isset($this->options['footer_copyright']) ? $this->options['footer_copyright'] : ''); ?>">
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('Endereço', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[footer_address]" value="<?php echo esc_attr(isset($this->options['footer_address']) ? $this->options['footer_address'] : ''); ?>">
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('Telefone', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[footer_phone]" value="<?php echo esc_attr(isset($this->options['footer_phone']) ? $this->options['footer_phone'] : ''); ?>">
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('Email', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[footer_email]" value="<?php echo esc_attr(isset($this->options['footer_email']) ? $this->options['footer_email'] : ''); ?>">
        </div>
        <?php
    }

    /**
     * Renderiza as opções de redes sociais
     */
    public function render_social_options() {
        ?>
        <div class="theme-options-field">
            <label><?php esc_html_e('Facebook', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[social_facebook]" value="<?php echo esc_attr(isset($this->options['social_facebook']) ? $this->options['social_facebook'] : ''); ?>">
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('Twitter', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[social_twitter]" value="<?php echo esc_attr(isset($this->options['social_twitter']) ? $this->options['social_twitter'] : ''); ?>">
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('Instagram', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[social_instagram]" value="<?php echo esc_attr(isset($this->options['social_instagram']) ? $this->options['social_instagram'] : ''); ?>">
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('YouTube', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[social_youtube]" value="<?php echo esc_attr(isset($this->options['social_youtube']) ? $this->options['social_youtube'] : ''); ?>">
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('LinkedIn', 'theme-espingardaria'); ?></label>
            <input type="text" name="theme_espingardaria_options[social_linkedin]" value="<?php echo esc_attr(isset($this->options['social_linkedin']) ? $this->options['social_linkedin'] : ''); ?>">
        </div>
        <?php
    }

    /**
     * Renderiza as opções avançadas
     */
    public function render_advanced_options() {
        ?>
        <div class="theme-options-field">
            <label><?php esc_html_e('Código de Rastreamento (Head)', 'theme-espingardaria'); ?></label>
            <textarea name="theme_espingardaria_options[tracking_head]" rows="5"><?php echo esc_textarea(isset($this->options['tracking_head']) ? $this->options['tracking_head'] : ''); ?></textarea>
            <p class="description"><?php esc_html_e('Este código será adicionado à seção head do site.', 'theme-espingardaria'); ?></p>
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('Código de Rastreamento (Footer)', 'theme-espingardaria'); ?></label>
            <textarea name="theme_espingardaria_options[tracking_footer]" rows="5"><?php echo esc_textarea(isset($this->options['tracking_footer']) ? $this->options['tracking_footer'] : ''); ?></textarea>
            <p class="description"><?php esc_html_e('Este código será adicionado ao final do site, antes do fechamento da tag body.', 'theme-espingardaria'); ?></p>
        </div>
        
        <div class="theme-options-field">
            <label><?php esc_html_e('CSS Personalizado', 'theme-espingardaria'); ?></label>
            <textarea name="theme_espingardaria_options[custom_css]" rows="10"><?php echo esc_textarea(isset($this->options['custom_css']) ? $this->options['custom_css'] : ''); ?></textarea>
        </div>
        <?php
    }
}
