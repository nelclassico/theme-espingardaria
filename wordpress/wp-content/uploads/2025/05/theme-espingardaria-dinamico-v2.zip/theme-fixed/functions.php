<?php
/**
 * Funções e definições do tema
 *
 * @package Theme_Espingardaria
 */

if (!defined('ABSPATH')) {
    exit; // Saída direta se acessado diretamente
}

/**
 * Define constantes do tema
 */
define('THEME_ESPINGARDARIA_VERSION', '3.0.0');
define('THEME_ESPINGARDARIA_DIR', get_template_directory());
define('THEME_ESPINGARDARIA_URI', get_template_directory_uri());

/**
 * Configuração do tema
 */
function theme_espingardaria_setup() {
    // Adiciona suporte a tradução
    load_theme_textdomain('theme-espingardaria', THEME_ESPINGARDARIA_DIR . '/languages');

    // Adiciona suporte a recursos do WordPress
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));
    add_theme_support('customize-selective-refresh-widgets');

    // Registra menus
    register_nav_menus(array(
        'primary' => esc_html__('Menu Principal', 'theme-espingardaria'),
        'footer' => esc_html__('Menu Rodapé', 'theme-espingardaria'),
    ));

    // Tamanhos de imagem personalizados
    add_image_size('theme-espingardaria-featured', 1200, 600, true);
    add_image_size('theme-espingardaria-product', 600, 600, true);
    add_image_size('theme-espingardaria-thumbnail', 300, 300, true);
}
add_action('after_setup_theme', 'theme_espingardaria_setup');

/**
 * Registra áreas de widgets
 */
function theme_espingardaria_widgets_init() {
    register_sidebar(array(
        'name'          => esc_html__('Sidebar', 'theme-espingardaria'),
        'id'            => 'sidebar-1',
        'description'   => esc_html__('Adicione widgets aqui.', 'theme-espingardaria'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Rodapé 1', 'theme-espingardaria'),
        'id'            => 'footer-1',
        'description'   => esc_html__('Adicione widgets aqui.', 'theme-espingardaria'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Rodapé 2', 'theme-espingardaria'),
        'id'            => 'footer-2',
        'description'   => esc_html__('Adicione widgets aqui.', 'theme-espingardaria'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Rodapé 3', 'theme-espingardaria'),
        'id'            => 'footer-3',
        'description'   => esc_html__('Adicione widgets aqui.', 'theme-espingardaria'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Rodapé 4', 'theme-espingardaria'),
        'id'            => 'footer-4',
        'description'   => esc_html__('Adicione widgets aqui.', 'theme-espingardaria'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'theme_espingardaria_widgets_init');

/**
 * Enfileira scripts e estilos
 */
function theme_espingardaria_scripts() {
    // Bootstrap CSS
    wp_enqueue_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css', array(), '5.3.0');
    
    // Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css', array(), '6.0.0');
    
    // Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap', array(), null);
    
    // Tema CSS
    wp_enqueue_style('theme-espingardaria-style', get_stylesheet_uri(), array(), THEME_ESPINGARDARIA_VERSION);
    wp_enqueue_style('theme-espingardaria-main', THEME_ESPINGARDARIA_URI . '/css/style.css', array(), THEME_ESPINGARDARIA_VERSION);
    
    // Bootstrap JS
    wp_enqueue_script('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js', array('jquery'), '5.3.0', true);
    
    // Tema JS
    wp_enqueue_script('theme-espingardaria-main', THEME_ESPINGARDARIA_URI . '/js/main.js', array('jquery'), THEME_ESPINGARDARIA_VERSION, true);

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'theme_espingardaria_scripts');

/**
 * Registra o tipo de post personalizado para produtos
 */
function theme_espingardaria_register_post_types() {
    $labels = array(
        'name'                  => _x('Produtos', 'Post type general name', 'theme-espingardaria'),
        'singular_name'         => _x('Produto', 'Post type singular name', 'theme-espingardaria'),
        'menu_name'             => _x('Produtos', 'Admin Menu text', 'theme-espingardaria'),
        'name_admin_bar'        => _x('Produto', 'Add New on Toolbar', 'theme-espingardaria'),
        'add_new'               => __('Adicionar Novo', 'theme-espingardaria'),
        'add_new_item'          => __('Adicionar Novo Produto', 'theme-espingardaria'),
        'new_item'              => __('Novo Produto', 'theme-espingardaria'),
        'edit_item'             => __('Editar Produto', 'theme-espingardaria'),
        'view_item'             => __('Ver Produto', 'theme-espingardaria'),
        'all_items'             => __('Todos os Produtos', 'theme-espingardaria'),
        'search_items'          => __('Buscar Produtos', 'theme-espingardaria'),
        'parent_item_colon'     => __('Produtos Pai:', 'theme-espingardaria'),
        'not_found'             => __('Nenhum produto encontrado.', 'theme-espingardaria'),
        'not_found_in_trash'    => __('Nenhum produto encontrado na lixeira.', 'theme-espingardaria'),
        'featured_image'        => __('Imagem Destacada do Produto', 'theme-espingardaria'),
        'set_featured_image'    => __('Definir imagem destacada', 'theme-espingardaria'),
        'remove_featured_image' => __('Remover imagem destacada', 'theme-espingardaria'),
        'use_featured_image'    => __('Usar como imagem destacada', 'theme-espingardaria'),
        'archives'              => __('Arquivos de Produto', 'theme-espingardaria'),
        'insert_into_item'      => __('Inserir no produto', 'theme-espingardaria'),
        'uploaded_to_this_item' => __('Enviado para este produto', 'theme-espingardaria'),
        'filter_items_list'     => __('Filtrar lista de produtos', 'theme-espingardaria'),
        'items_list_navigation' => __('Navegação da lista de produtos', 'theme-espingardaria'),
        'items_list'            => __('Lista de produtos', 'theme-espingardaria'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'produto'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-cart',
        'supports'           => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
    );

    register_post_type('produto', $args);

    // Registra taxonomias para produtos
    $category_labels = array(
        'name'                       => _x('Categorias de Produto', 'taxonomy general name', 'theme-espingardaria'),
        'singular_name'              => _x('Categoria de Produto', 'taxonomy singular name', 'theme-espingardaria'),
        'search_items'               => __('Buscar Categorias', 'theme-espingardaria'),
        'popular_items'              => __('Categorias Populares', 'theme-espingardaria'),
        'all_items'                  => __('Todas as Categorias', 'theme-espingardaria'),
        'parent_item'                => __('Categoria Pai', 'theme-espingardaria'),
        'parent_item_colon'          => __('Categoria Pai:', 'theme-espingardaria'),
        'edit_item'                  => __('Editar Categoria', 'theme-espingardaria'),
        'update_item'                => __('Atualizar Categoria', 'theme-espingardaria'),
        'add_new_item'               => __('Adicionar Nova Categoria', 'theme-espingardaria'),
        'new_item_name'              => __('Nome da Nova Categoria', 'theme-espingardaria'),
        'separate_items_with_commas' => __('Separe as categorias com vírgulas', 'theme-espingardaria'),
        'add_or_remove_items'        => __('Adicionar ou remover categorias', 'theme-espingardaria'),
        'choose_from_most_used'      => __('Escolha entre as categorias mais usadas', 'theme-espingardaria'),
        'not_found'                  => __('Nenhuma categoria encontrada.', 'theme-espingardaria'),
        'menu_name'                  => __('Categorias', 'theme-espingardaria'),
    );

    $category_args = array(
        'hierarchical'      => true,
        'labels'            => $category_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'categoria-produto'),
    );

    register_taxonomy('categoria-produto', array('produto'), $category_args);

    // Taxonomia para marca
    $brand_labels = array(
        'name'                       => _x('Marcas', 'taxonomy general name', 'theme-espingardaria'),
        'singular_name'              => _x('Marca', 'taxonomy singular name', 'theme-espingardaria'),
        'search_items'               => __('Buscar Marcas', 'theme-espingardaria'),
        'popular_items'              => __('Marcas Populares', 'theme-espingardaria'),
        'all_items'                  => __('Todas as Marcas', 'theme-espingardaria'),
        'edit_item'                  => __('Editar Marca', 'theme-espingardaria'),
        'update_item'                => __('Atualizar Marca', 'theme-espingardaria'),
        'add_new_item'               => __('Adicionar Nova Marca', 'theme-espingardaria'),
        'new_item_name'              => __('Nome da Nova Marca', 'theme-espingardaria'),
        'separate_items_with_commas' => __('Separe as marcas com vírgulas', 'theme-espingardaria'),
        'add_or_remove_items'        => __('Adicionar ou remover marcas', 'theme-espingardaria'),
        'choose_from_most_used'      => __('Escolha entre as marcas mais usadas', 'theme-espingardaria'),
        'not_found'                  => __('Nenhuma marca encontrada.', 'theme-espingardaria'),
        'menu_name'                  => __('Marcas', 'theme-espingardaria'),
    );

    $brand_args = array(
        'hierarchical'      => false,
        'labels'            => $brand_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'marca'),
    );

    register_taxonomy('marca', array('produto'), $brand_args);

    // Taxonomia para calibre
    $caliber_labels = array(
        'name'                       => _x('Calibres', 'taxonomy general name', 'theme-espingardaria'),
        'singular_name'              => _x('Calibre', 'taxonomy singular name', 'theme-espingardaria'),
        'search_items'               => __('Buscar Calibres', 'theme-espingardaria'),
        'popular_items'              => __('Calibres Populares', 'theme-espingardaria'),
        'all_items'                  => __('Todos os Calibres', 'theme-espingardaria'),
        'edit_item'                  => __('Editar Calibre', 'theme-espingardaria'),
        'update_item'                => __('Atualizar Calibre', 'theme-espingardaria'),
        'add_new_item'               => __('Adicionar Novo Calibre', 'theme-espingardaria'),
        'new_item_name'              => __('Nome do Novo Calibre', 'theme-espingardaria'),
        'separate_items_with_commas' => __('Separe os calibres com vírgulas', 'theme-espingardaria'),
        'add_or_remove_items'        => __('Adicionar ou remover calibres', 'theme-espingardaria'),
        'choose_from_most_used'      => __('Escolha entre os calibres mais usados', 'theme-espingardaria'),
        'not_found'                  => __('Nenhum calibre encontrado.', 'theme-espingardaria'),
        'menu_name'                  => __('Calibres', 'theme-espingardaria'),
    );

    $caliber_args = array(
        'hierarchical'      => false,
        'labels'            => $caliber_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'calibre'),
    );

    register_taxonomy('calibre', array('produto'), $caliber_args);
}
add_action('init', 'theme_espingardaria_register_post_types');

/**
 * Adiciona meta boxes para produtos
 */
function theme_espingardaria_add_meta_boxes() {
    add_meta_box(
        'theme_espingardaria_product_details',
        __('Detalhes do Produto', 'theme-espingardaria'),
        'theme_espingardaria_product_details_callback',
        'produto',
        'normal',
        'high'
    );

    add_meta_box(
        'theme_espingardaria_product_gallery',
        __('Galeria de Imagens', 'theme-espingardaria'),
        'theme_espingardaria_product_gallery_callback',
        'produto',
        'normal',
        'high'
    );

    add_meta_box(
        'theme_espingardaria_product_classes',
        __('Classes e Modalidades', 'theme-espingardaria'),
        'theme_espingardaria_product_classes_callback',
        'produto',
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'theme_espingardaria_add_meta_boxes');

/**
 * Callback para meta box de detalhes do produto
 */
function theme_espingardaria_product_details_callback($post) {
    wp_nonce_field('theme_espingardaria_product_details', 'theme_espingardaria_product_details_nonce');

    $modelo = get_post_meta($post->ID, '_modelo', true);
    $comprimento_cano = get_post_meta($post->ID, '_comprimento_cano', true);
    $capacidade = get_post_meta($post->ID, '_capacidade', true);
    $peso = get_post_meta($post->ID, '_peso', true);
    $preco = get_post_meta($post->ID, '_preco', true);
    $preco_regular = get_post_meta($post->ID, '_preco_regular', true);
    $informacoes_diversas = get_post_meta($post->ID, '_informacoes_diversas', true);
    $destaque = get_post_meta($post->ID, '_destaque', true);
    ?>
    <div class="theme-espingardaria-meta-box">
        <p>
            <label for="modelo"><?php esc_html_e('Modelo:', 'theme-espingardaria'); ?></label>
            <input type="text" id="modelo" name="modelo" value="<?php echo esc_attr($modelo); ?>" class="widefat">
        </p>
        <p>
            <label for="comprimento_cano"><?php esc_html_e('Comprimento do Cano:', 'theme-espingardaria'); ?></label>
            <input type="text" id="comprimento_cano" name="comprimento_cano" value="<?php echo esc_attr($comprimento_cano); ?>" class="widefat">
        </p>
        <p>
            <label for="capacidade"><?php esc_html_e('Capacidade:', 'theme-espingardaria'); ?></label>
            <input type="text" id="capacidade" name="capacidade" value="<?php echo esc_attr($capacidade); ?>" class="widefat">
        </p>
        <p>
            <label for="peso"><?php esc_html_e('Peso:', 'theme-espingardaria'); ?></label>
            <input type="text" id="peso" name="peso" value="<?php echo esc_attr($peso); ?>" class="widefat">
        </p>
        <p>
            <label for="preco"><?php esc_html_e('Preço:', 'theme-espingardaria'); ?></label>
            <input type="text" id="preco" name="preco" value="<?php echo esc_attr($preco); ?>" class="widefat">
        </p>
        <p>
            <label for="preco_regular"><?php esc_html_e('Preço Regular (para produtos em promoção):', 'theme-espingardaria'); ?></label>
            <input type="text" id="preco_regular" name="preco_regular" value="<?php echo esc_attr($preco_regular); ?>" class="widefat">
        </p>
        <p>
            <label for="informacoes_diversas"><?php esc_html_e('Informações Diversas:', 'theme-espingardaria'); ?></label>
            <textarea id="informacoes_diversas" name="informacoes_diversas" class="widefat" rows="5"><?php echo esc_textarea($informacoes_diversas); ?></textarea>
        </p>
        <p>
            <input type="checkbox" id="destaque" name="destaque" value="1" <?php checked($destaque, '1'); ?>>
            <label for="destaque"><?php esc_html_e('Produto em Destaque', 'theme-espingardaria'); ?></label>
        </p>
    </div>
    <?php
}

/**
 * Callback para meta box de galeria de imagens
 */
function theme_espingardaria_product_gallery_callback($post) {
    wp_nonce_field('theme_espingardaria_product_gallery', 'theme_espingardaria_product_gallery_nonce');

    $gallery_images = get_post_meta($post->ID, '_gallery_images', true);
    ?>
    <div class="theme-espingardaria-meta-box">
        <p><?php esc_html_e('Adicione imagens à galeria do produto.', 'theme-espingardaria'); ?></p>
        <div class="product-gallery-container">
            <div class="product-gallery-preview">
                <?php
                if (!empty($gallery_images)) {
                    $gallery_images = explode(',', $gallery_images);
                    foreach ($gallery_images as $image_id) {
                        $image = wp_get_attachment_image_src($image_id, 'thumbnail');
                        if ($image) {
                            echo '<div class="gallery-image-preview" data-id="' . esc_attr($image_id) . '">';
                            echo '<img src="' . esc_url($image[0]) . '" alt="">';
                            echo '<a href="#" class="remove-image">×</a>';
                            echo '</div>';
                        }
                    }
                }
                ?>
            </div>
            <input type="hidden" name="gallery_images" id="gallery_images" value="<?php echo esc_attr(get_post_meta($post->ID, '_gallery_images', true)); ?>">
            <button type="button" class="button add-gallery-images"><?php esc_html_e('Adicionar Imagens', 'theme-espingardaria'); ?></button>
        </div>
    </div>
    <script>
    jQuery(document).ready(function($) {
        // Adicionar imagens à galeria
        $('.add-gallery-images').on('click', function(e) {
            e.preventDefault();

            var galleryFrame = wp.media({
                title: '<?php esc_html_e('Selecionar Imagens', 'theme-espingardaria'); ?>',
                button: {
                    text: '<?php esc_html_e('Adicionar à Galeria', 'theme-espingardaria'); ?>'
                },
                multiple: true
            });

            galleryFrame.on('select', function() {
                var attachments = galleryFrame.state().get('selection').toJSON();
                var galleryPreview = $('.product-gallery-preview');
                var galleryInput = $('#gallery_images');
                var galleryIds = galleryInput.val() ? galleryInput.val().split(',') : [];

                $.each(attachments, function(index, attachment) {
                    if ($.inArray(attachment.id.toString(), galleryIds) === -1) {
                        galleryIds.push(attachment.id);
                        galleryPreview.append('<div class="gallery-image-preview" data-id="' + attachment.id + '"><img src="' + attachment.sizes.thumbnail.url + '" alt=""><a href="#" class="remove-image">×</a></div>');
                    }
                });

                galleryInput.val(galleryIds.join(','));
            });

            galleryFrame.open();
        });

        // Remover imagem da galeria
        $('.product-gallery-preview').on('click', '.remove-image', function(e) {
            e.preventDefault();

            var galleryPreview = $(this).parent();
            var galleryInput = $('#gallery_images');
            var galleryIds = galleryInput.val().split(',');
            var imageId = galleryPreview.data('id').toString();
            var imageIndex = galleryIds.indexOf(imageId);

            if (imageIndex !== -1) {
                galleryIds.splice(imageIndex, 1);
                galleryInput.val(galleryIds.join(','));
                galleryPreview.remove();
            }
        });
    });
    </script>
    <style>
    .product-gallery-preview {
        display: flex;
        flex-wrap: wrap;
        margin: 10px 0;
    }
    .gallery-image-preview {
        position: relative;
        width: 80px;
        height: 80px;
        margin: 0 10px 10px 0;
        border: 1px solid #ddd;
        border-radius: 3px;
        overflow: hidden;
    }
    .gallery-image-preview img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .remove-image {
        position: absolute;
        top: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.5);
        color: #fff;
        width: 20px;
        height: 20px;
        line-height: 18px;
        text-align: center;
        text-decoration: none;
        font-size: 16px;
        font-weight: bold;
    }
    </style>
    <?php
}

/**
 * Callback para meta box de classes e modalidades
 */
function theme_espingardaria_product_classes_callback($post) {
    wp_nonce_field('theme_espingardaria_product_classes', 'theme_espingardaria_product_classes_nonce');

    $classes = array(
        'classe_a' => __('Classe A', 'theme-espingardaria'),
        'classe_b' => __('Classe B', 'theme-espingardaria'),
        'classe_b1' => __('Classe B1', 'theme-espingardaria'),
        'classe_c' => __('Classe C', 'theme-espingardaria'),
        'classe_d' => __('Classe D', 'theme-espingardaria'),
    );

    $modalidades = array(
        'tiro_desportivo' => __('Tiro Desportivo', 'theme-espingardaria'),
        'ipsc_production' => __('IPSC Production', 'theme-espingardaria'),
        'ipsc_standard' => __('IPSC Standard', 'theme-espingardaria'),
        'ipsc_classic' => __('IPSC Classic', 'theme-espingardaria'),
        'ipsc_open' => __('IPSC Open', 'theme-espingardaria'),
    );
    ?>
    <div class="theme-espingardaria-meta-box">
        <p><strong><?php esc_html_e('Classes:', 'theme-espingardaria'); ?></strong></p>
        <?php foreach ($classes as $key => $label) : ?>
            <p>
                <input type="checkbox" id="<?php echo esc_attr($key); ?>" name="<?php echo esc_attr($key); ?>" value="1" <?php checked(get_post_meta($post->ID, '_' . $key, true), '1'); ?>>
                <label for="<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></label>
            </p>
        <?php endforeach; ?>

        <p><strong><?php esc_html_e('Modalidades de Tiro:', 'theme-espingardaria'); ?></strong></p>
        <?php foreach ($modalidades as $key => $label) : ?>
            <p>
                <input type="checkbox" id="<?php echo esc_attr($key); ?>" name="<?php echo esc_attr($key); ?>" value="1" <?php checked(get_post_meta($post->ID, '_' . $key, true), '1'); ?>>
                <label for="<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></label>
            </p>
        <?php endforeach; ?>
    </div>
    <?php
}

/**
 * Salva os meta boxes
 */
function theme_espingardaria_save_meta_boxes($post_id) {
    // Verifica se é um salvamento automático
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Verifica o tipo de post
    if (!isset($_POST['post_type']) || 'produto' != $_POST['post_type']) {
        return;
    }

    // Verifica as permissões
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Salva os detalhes do produto
    if (isset($_POST['theme_espingardaria_product_details_nonce']) && wp_verify_nonce($_POST['theme_espingardaria_product_details_nonce'], 'theme_espingardaria_product_details')) {
        $fields = array(
            'modelo',
            'comprimento_cano',
            'capacidade',
            'peso',
            'preco',
            'preco_regular',
            'informacoes_diversas',
        );

        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
            }
        }

        // Checkbox para destaque
        $destaque = isset($_POST['destaque']) ? '1' : '0';
        update_post_meta($post_id, '_destaque', $destaque);
    }

    // Salva a galeria de imagens
    if (isset($_POST['theme_espingardaria_product_gallery_nonce']) && wp_verify_nonce($_POST['theme_espingardaria_product_gallery_nonce'], 'theme_espingardaria_product_gallery')) {
        if (isset($_POST['gallery_images'])) {
            update_post_meta($post_id, '_gallery_images', sanitize_text_field($_POST['gallery_images']));
        }
    }

    // Salva as classes e modalidades
    if (isset($_POST['theme_espingardaria_product_classes_nonce']) && wp_verify_nonce($_POST['theme_espingardaria_product_classes_nonce'], 'theme_espingardaria_product_classes')) {
        $classes = array(
            'classe_a',
            'classe_b',
            'classe_b1',
            'classe_c',
            'classe_d',
        );

        $modalidades = array(
            'tiro_desportivo',
            'ipsc_production',
            'ipsc_standard',
            'ipsc_classic',
            'ipsc_open',
        );

        foreach (array_merge($classes, $modalidades) as $field) {
            $value = isset($_POST[$field]) ? '1' : '0';
            update_post_meta($post_id, '_' . $field, $value);
        }
    }
}
add_action('save_post', 'theme_espingardaria_save_meta_boxes');

/**
 * Adiciona suporte a templates personalizados para produtos
 */
function theme_espingardaria_add_product_templates($templates) {
    $post_templates = array(
        'single-standard.php' => __('Single Standard', 'theme-espingardaria'),
    );
    return array_merge($templates, $post_templates);
}
add_filter('theme_templates', 'theme_espingardaria_add_product_templates');

/**
 * Adiciona suporte a templates personalizados para páginas
 */
function theme_espingardaria_add_page_templates($templates) {
    $page_templates = array(
        'page-fullwidth.php' => __('Página Fullwidth', 'theme-espingardaria'),
        'page-columns.php' => __('Página com Colunas', 'theme-espingardaria'),
        'page-portfolio.php' => __('Página de Portfolio', 'theme-espingardaria'),
        'page-services.php' => __('Página de Serviços', 'theme-espingardaria'),
    );
    return array_merge($templates, $page_templates);
}
add_filter('theme_page_templates', 'theme_espingardaria_add_page_templates');

/**
 * Inclui o arquivo de opções do tema
 */
if (file_exists(THEME_ESPINGARDARIA_DIR . '/inc/theme-options.php')) {
    require_once THEME_ESPINGARDARIA_DIR . '/inc/theme-options.php';
}

/**
 * Inclui o arquivo de suporte multilíngue
 */
if (file_exists(THEME_ESPINGARDARIA_DIR . '/inc/multilingual.php')) {
    require_once THEME_ESPINGARDARIA_DIR . '/inc/multilingual.php';
}

/**
 * Inicializa o painel de opções do tema
 */
function theme_espingardaria_init_options() {
    if (class_exists('Theme_Espingardaria_Options')) {
        $theme_options = new Theme_Espingardaria_Options();
    }
}
add_action('after_setup_theme', 'theme_espingardaria_init_options');

/**
 * Obtém as opções do tema
 */
function theme_espingardaria_get_options() {
    return get_option('theme_espingardaria_options', array());
}

/**
 * Obtém uma opção específica do tema
 */
function theme_espingardaria_get_option($key, $default = '') {
    $options = theme_espingardaria_get_options();
    return isset($options[$key]) ? $options[$key] : $default;
}
