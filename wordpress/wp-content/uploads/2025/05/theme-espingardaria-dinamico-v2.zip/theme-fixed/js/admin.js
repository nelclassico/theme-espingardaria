/**
 * JavaScript para o painel de opções do tema
 *
 * @package Theme_Espingardaria
 */

jQuery(document).ready(function($) {
    // Tabs
    $('.theme-options-tabs-nav a').on('click', function(e) {
        e.preventDefault();
        
        var target = $(this).attr('href');
        
        // Ativa a tab
        $('.theme-options-tabs-nav li').removeClass('active');
        $(this).parent().addClass('active');
        
        // Mostra o conteúdo da tab
        $('.theme-options-tab').removeClass('active');
        $(target).addClass('active');
    });
    
    // Accordion
    $('.theme-options-section-header').on('click', function() {
        $(this).next('.theme-options-section-content').slideToggle();
        $(this).parent().toggleClass('open');
    });
    
    // Media Uploader
    $('.upload-media').on('click', function(e) {
        e.preventDefault();
        
        var button = $(this);
        var mediaUploader = button.closest('.media-uploader');
        var mediaInput = mediaUploader.find('input[type="hidden"]');
        var mediaPreview = mediaUploader.find('.media-preview');
        
        var mediaFrame = wp.media({
            title: themeEspingardaria.mediaTitle,
            button: {
                text: themeEspingardaria.mediaButton
            },
            multiple: false
        });
        
        mediaFrame.on('select', function() {
            var attachment = mediaFrame.state().get('selection').first().toJSON();
            mediaInput.val(attachment.url);
            mediaPreview.html('<img src="' + attachment.url + '" alt="">');
        });
        
        mediaFrame.open();
    });
    
    // Remover imagem
    $('.remove-media').on('click', function(e) {
        e.preventDefault();
        
        var button = $(this);
        var mediaUploader = button.closest('.media-uploader');
        var mediaInput = mediaUploader.find('input[type="hidden"]');
        var mediaPreview = mediaUploader.find('.media-preview');
        
        mediaInput.val('');
        mediaPreview.html('');
    });
    
    // Sortable
    $('.theme-options-sortable').sortable({
        handle: '.theme-options-sortable-item-header',
        placeholder: 'theme-options-sortable-placeholder',
        update: function(event, ui) {
            updateSortableIndexes($(this));
        }
    });
    
    // Toggle sortable item
    $('.theme-options-sortable').on('click', '.theme-options-sortable-item-toggle', function(e) {
        e.preventDefault();
        
        var item = $(this).closest('.theme-options-sortable-item');
        var content = item.find('.theme-options-sortable-item-content');
        
        content.slideToggle();
        item.toggleClass('open');
        
        var icon = $(this).find('.dashicons');
        if (item.hasClass('open')) {
            icon.removeClass('dashicons-arrow-down').addClass('dashicons-arrow-up');
        } else {
            icon.removeClass('dashicons-arrow-up').addClass('dashicons-arrow-down');
        }
    });
    
    // Remover sortable item
    $('.theme-options-sortable').on('click', '.theme-options-sortable-item-remove', function(e) {
        e.preventDefault();
        
        var item = $(this).closest('.theme-options-sortable-item');
        var sortable = item.parent();
        
        item.remove();
        updateSortableIndexes(sortable);
    });
    
    // Adicionar slide
    $('.add-slide').on('click', function(e) {
        e.preventDefault();
        
        var sortable = $('.slides-sortable');
        var index = sortable.find('.theme-options-sortable-item').length;
        
        var template = `
            <li class="theme-options-sortable-item">
                <div class="theme-options-sortable-item-header">
                    <span class="theme-options-sortable-item-title">${themeEspingardaria.addText} ${index + 1}</span>
                    <div class="theme-options-sortable-item-actions">
                        <button type="button" class="theme-options-sortable-item-toggle"><span class="dashicons dashicons-arrow-down"></span></button>
                        <button type="button" class="theme-options-sortable-item-remove"><span class="dashicons dashicons-trash"></span></button>
                    </div>
                </div>
                
                <div class="theme-options-sortable-item-content">
                    <div class="theme-options-field">
                        <label>${themeEspingardaria.mediaTitle}</label>
                        <div class="media-uploader">
                            <input type="hidden" name="theme_espingardaria_options[slider][${index}][image]" value="">
                            <div class="media-preview"></div>
                            <div class="media-buttons">
                                <button type="button" class="button upload-media">${themeEspingardaria.mediaTitle}</button>
                                <button type="button" class="button remove-media">${themeEspingardaria.removeText}</button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="theme-options-field">
                        <label>Título</label>
                        <input type="text" name="theme_espingardaria_options[slider][${index}][title]" value="">
                    </div>
                    
                    <div class="theme-options-field">
                        <label>Subtítulo</label>
                        <input type="text" name="theme_espingardaria_options[slider][${index}][subtitle]" value="">
                    </div>
                    
                    <div class="theme-options-field">
                        <label>Preço</label>
                        <input type="text" name="theme_espingardaria_options[slider][${index}][price]" value="">
                    </div>
                    
                    <div class="theme-options-field">
                        <label>Texto do Botão</label>
                        <input type="text" name="theme_espingardaria_options[slider][${index}][button_text]" value="">
                    </div>
                    
                    <div class="theme-options-field">
                        <label>URL do Botão</label>
                        <input type="text" name="theme_espingardaria_options[slider][${index}][button_url]" value="">
                    </div>
                </div>
            </li>
        `;
        
        sortable.append(template);
    });
    
    // Adicionar item de compra
    $('.add-shop-item').on('click', function(e) {
        e.preventDefault();
        
        var sortable = $('.shop-items-sortable');
        var index = sortable.find('.theme-options-sortable-item').length;
        
        var template = `
            <li class="theme-options-sortable-item">
                <div class="theme-options-sortable-item-header">
                    <span class="theme-options-sortable-item-title">${themeEspingardaria.addText} ${index + 1}</span>
                    <div class="theme-options-sortable-item-actions">
                        <button type="button" class="theme-options-sortable-item-toggle"><span class="dashicons dashicons-arrow-down"></span></button>
                        <button type="button" class="theme-options-sortable-item-remove"><span class="dashicons dashicons-trash"></span></button>
                    </div>
                </div>
                
                <div class="theme-options-sortable-item-content">
                    <div class="theme-options-field">
                        <label>${themeEspingardaria.mediaTitle}</label>
                        <div class="media-uploader">
                            <input type="hidden" name="theme_espingardaria_options[shop_anywhere_items][${index}][image]" value="">
                            <div class="media-preview"></div>
                            <div class="media-buttons">
                                <button type="button" class="button upload-media">${themeEspingardaria.mediaTitle}</button>
                                <button type="button" class="button remove-media">${themeEspingardaria.removeText}</button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="theme-options-field">
                        <label>Título</label>
                        <input type="text" name="theme_espingardaria_options[shop_anywhere_items][${index}][title]" value="">
                    </div>
                    
                    <div class="theme-options-field">
                        <label>URL</label>
                        <input type="text" name="theme_espingardaria_options[shop_anywhere_items][${index}][url]" value="">
                    </div>
                </div>
            </li>
        `;
        
        sortable.append(template);
    });
    
    // Adicionar avaliação
    $('.add-review').on('click', function(e) {
        e.preventDefault();
        
        var sortable = $('.reviews-sortable');
        var index = sortable.find('.theme-options-sortable-item').length;
        
        var template = `
            <li class="theme-options-sortable-item">
                <div class="theme-options-sortable-item-header">
                    <span class="theme-options-sortable-item-title">${themeEspingardaria.addText} ${index + 1}</span>
                    <div class="theme-options-sortable-item-actions">
                        <button type="button" class="theme-options-sortable-item-toggle"><span class="dashicons dashicons-arrow-down"></span></button>
                        <button type="button" class="theme-options-sortable-item-remove"><span class="dashicons dashicons-trash"></span></button>
                    </div>
                </div>
                
                <div class="theme-options-sortable-item-content">
                    <div class="theme-options-field">
                        <label>Texto da Avaliação</label>
                        <textarea name="theme_espingardaria_options[reviews][${index}][text]" rows="5"></textarea>
                    </div>
                    
                    <div class="theme-options-field">
                        <label>Nome do Autor</label>
                        <input type="text" name="theme_espingardaria_options[reviews][${index}][author]" value="">
                    </div>
                    
                    <div class="theme-options-field">
                        <label>Avaliação (1-5)</label>
                        <input type="number" name="theme_espingardaria_options[reviews][${index}][rating]" value="5" min="1" max="5">
                    </div>
                    
                    <div class="theme-options-field">
                        <label>Imagem do Autor</label>
                        <div class="media-uploader">
                            <input type="hidden" name="theme_espingardaria_options[reviews][${index}][image]" value="">
                            <div class="media-preview"></div>
                            <div class="media-buttons">
                                <button type="button" class="button upload-media">${themeEspingardaria.mediaTitle}</button>
                                <button type="button" class="button remove-media">${themeEspingardaria.removeText}</button>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
        `;
        
        sortable.append(template);
    });
    
    // Atualiza os índices dos itens sortable
    function updateSortableIndexes(sortable) {
        sortable.find('.theme-options-sortable-item').each(function(index) {
            var item = $(this);
            var type = '';
            
            if (sortable.hasClass('slides-sortable')) {
                type = 'slider';
            } else if (sortable.hasClass('shop-items-sortable')) {
                type = 'shop_anywhere_items';
            } else if (sortable.hasClass('reviews-sortable')) {
                type = 'reviews';
            }
            
            item.find('input, textarea').each(function() {
                var input = $(this);
                var name = input.attr('name');
                
                if (name) {
                    var newName = name.replace(/\[\d+\]/, '[' + index + ']');
                    input.attr('name', newName);
                }
            });
        });
    }
});
