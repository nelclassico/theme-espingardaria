# Tutorial: Como Usar o Tema Dinâmico Espingardaria

Este tutorial explica como utilizar todas as opções dinâmicas do tema Espingardaria, permitindo que você personalize completamente o visual do seu site através do painel administrativo.

## Índice
1. [Acessando as Opções do Tema](#acessando-as-opções-do-tema)
2. [Personalizando o Header](#personalizando-o-header)
3. [Personalizando a Página Inicial](#personalizando-a-página-inicial)
4. [Ativando e Desativando Seções](#ativando-e-desativando-seções)
5. [Editando Títulos e Conteúdos](#editando-títulos-e-conteúdos)
6. [Personalizando Cores](#personalizando-cores)

## Acessando as Opções do Tema

Existem duas maneiras principais de personalizar o tema:

### 1. Através do Customizer

1. No painel administrativo do WordPress, vá para **Aparência > Personalizar**
2. Você verá várias seções onde pode modificar cores, informações do header e outros elementos visuais

### 2. Através das Opções do Tema

1. No painel administrativo, vá para **Aparência > Opções do Tema**
2. Aqui você encontrará opções mais avançadas para personalizar a página inicial e outras seções

## Personalizando o Header

O header do site pode ser completamente personalizado:

### Barra Superior

1. No Customizer, vá para **Configurações do Header**
2. Você pode ativar/desativar a barra superior usando a opção "Mostrar Barra Superior"
3. Adicione informações de contato como telefone, email e horário de funcionamento
4. Todas essas informações aparecerão na barra superior do site

### Redes Sociais

1. No Customizer, vá para **Redes Sociais**
2. Adicione os links para suas páginas de redes sociais (Facebook, Instagram, Twitter, YouTube)
3. Os ícones aparecerão automaticamente na barra superior

### Carrinho de Compras

1. No Customizer, vá para **Configurações do Header**
2. Você pode ativar/desativar o ícone de carrinho usando a opção "Mostrar Carrinho"
3. Defina a URL para onde o botão do carrinho deve direcionar

### Logo

1. No Customizer, vá para **Identidade do Site**
2. Clique em "Selecionar logo" para fazer upload da sua logo
3. A logo substituirá automaticamente o nome do site no header

## Personalizando a Página Inicial

A página inicial é totalmente dinâmica e pode ser personalizada seção por seção:

### Banner Principal (Slider)

1. Em **Aparência > Opções do Tema**, vá para a aba "Home Page"
2. Encontre a seção "Banner Principal (Slider)"
3. Ative ou desative esta seção usando o botão de alternância
4. Clique em "Adicionar Slide" para criar novos slides
5. Para cada slide, você pode definir:
   - Imagem de fundo
   - Título
   - Subtítulo
   - Preço (se aplicável)
   - Texto e URL do botão
6. Arraste e solte os slides para reordenar

### Categorias de Produtos

1. Na mesma aba "Home Page", encontre a seção "Categorias de Produtos"
2. Ative ou desative esta seção
3. Defina um título personalizado para a seção
4. Selecione quais categorias de produtos deseja exibir

### Produtos em Destaque

1. Encontre a seção "Produtos em Destaque"
2. Ative ou desative esta seção
3. Defina um título personalizado
4. Escolha uma categoria específica (opcional)
5. Defina quantos produtos deseja exibir

### Seções Adicionais

Todas as seções seguintes funcionam de maneira similar:
- Seção de Treinamento
- Seção de Munições
- Compre em Qualquer Lugar
- Avaliações de Clientes
- Novos Produtos
- Blog e Notícias
- Sobre Nós

Para cada uma delas, você pode:
1. Ativar ou desativar a seção
2. Personalizar o título
3. Adicionar conteúdo específico (texto, imagens, botões)
4. Para seções com múltiplos itens, adicionar, remover ou reordenar itens

## Ativando e Desativando Seções

Cada seção da página inicial pode ser ativada ou desativada independentemente:

1. Em **Aparência > Opções do Tema**, vá para a aba "Home Page"
2. Cada seção tem um botão de alternância no canto superior direito
3. Clique neste botão para ativar (azul) ou desativar (cinza) a seção
4. As alterações serão aplicadas após salvar as opções

## Editando Títulos e Conteúdos

Todos os títulos e conteúdos das seções são editáveis:

1. Em cada seção, você encontrará campos para editar títulos, textos e outros conteúdos
2. Para textos mais longos, você terá um editor de texto completo
3. Para imagens, clique em "Selecionar Imagem" para fazer upload ou escolher uma imagem da biblioteca
4. Para botões, você pode editar tanto o texto quanto a URL de destino

## Personalizando Cores

O tema permite personalizar as cores principais:

1. No Customizer, vá para **Cores**
2. Você pode personalizar:
   - Cor Primária (usada em botões e links)
   - Cor Secundária
   - Cor de Fundo do Header
   - Cor de Fundo da Barra Superior
3. As alterações são visualizadas em tempo real antes de salvar

## Dicas Adicionais

- **Salve frequentemente**: Sempre clique em "Salvar alterações" após fazer modificações
- **Visualize antes de publicar**: Use a função de pré-visualização para verificar como as alterações ficarão
- **Imagens**: Use imagens de alta qualidade e nas dimensões recomendadas para melhores resultados
- **Responsividade**: O tema é totalmente responsivo, mas verifique como ele aparece em dispositivos móveis após personalizações significativas

Esperamos que este tutorial ajude você a aproveitar ao máximo todas as opções dinâmicas do tema Espingardaria!
